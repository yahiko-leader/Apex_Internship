// Theme toggle
const root = document.documentElement;
const themeToggle = document.getElementById('themeToggle');
const saved = localStorage.getItem('theme');
if(saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches)){
  root.classList.add('dark');
}
themeToggle?.addEventListener('click', ()=>{
  root.classList.toggle('dark');
  localStorage.setItem('theme', root.classList.contains('dark') ? 'dark' : 'light');
});

// Mobile menu
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
hamburger?.addEventListener('click', ()=>{
  hamburger.classList.toggle('open');
  mobileMenu.classList.toggle('open');
});
mobileMenu?.querySelectorAll('a').forEach(a=>{
  a.addEventListener('click', ()=>{
    hamburger.classList.remove('open');
    mobileMenu.classList.remove('open');
  });
});

// Tilt card
const card = document.getElementById('tiltCard');
if(card){
  let bounds;
  const updateBounds = ()=> bounds = card.getBoundingClientRect();
  updateBounds();
  window.addEventListener('resize', updateBounds);
  card.addEventListener('mousemove', (e)=>{
    const x = (e.clientX - bounds.left) / bounds.width - 0.5;
    const y = (e.clientY - bounds.top) / bounds.height - 0.5;
    card.style.transform = `perspective(900px) rotateY(${x*8}deg) rotateX(${-y*8}deg) translateY(-3px)`;
  });
  card.addEventListener('mouseleave', ()=>{
    card.style.transform = 'perspective(900px) rotateY(0deg) rotateX(0deg)';
  });
}

// Project filters
const pills = document.querySelectorAll('#filterPills button');
const projects = document.querySelectorAll('.project-card');
pills.forEach(btn=>{
  btn.addEventListener('click', ()=>{
    pills.forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const f = btn.dataset.filter;
    projects.forEach(p=>{
      const show = f==='all' || p.dataset.tags.includes(f);
      p.style.display = show ? '' : 'none';
      if(show){
        p.style.opacity='0';
        p.style.transform='translateY(12px)';
        setTimeout(()=>{p.style.opacity='';p.style.transform=''}, 40);
      }
    });
  });
});

// Scroll reveal
const io = new IntersectionObserver(entries=>{
  entries.forEach(en=>{
    if(en.isIntersecting){
      en.target.classList.add('revealed');
      io.unobserve(en.target);
    }
  });
}, {threshold: .12});
document.querySelectorAll('.project-card, .tl-item, .about-copy, .contact-form').forEach(el=>io.observe(el));

// Contact form – fake send with validation
const form = document.getElementById('contactForm');
const note = document.getElementById('formNote');
form?.addEventListener('submit', e=>{
  e.preventDefault();
  const data = new FormData(form);
  const name = data.get('name')?.toString().trim();
  const email = data.get('email')?.toString().trim();
  const message = data.get('message')?.toString().trim();
  if(!name || !email || !message || !email.includes('@')){
    note.style.color = '#dd4a2a';
    note.textContent = 'Please fill all required fields with a valid email.';
    return;
  }
  note.style.color = '';
  note.textContent = 'Sending…';
  setTimeout(()=>{
    note.textContent = `Thanks, ${name}! I’ll reply at ${email} within 6 hrs.`;
    form.reset();
  }, 900);
});

// CV download – link to uploaded CV if present
document.getElementById('downloadCv')?.addEventListener('click', (e)=>{
  e.preventDefault();
  // Try to use the uploaded CV
  const a = document.createElement('a');
  a.href = '../uploads/CV_2026-03-23-093725 (1).pdf';
  a.download = 'Nikhil-Prajapati-CV.pdf';
  document.body.appendChild(a);
  a.click();
  a.remove();
  // fallback toast
  setTimeout(()=>{
    const n = document.getElementById('formNote');
    if(n) n.textContent = 'CV download started.';
  }, 200);
});

// Back to top
document.getElementById('backToTop')?.addEventListener('click', e=>{
  e.preventDefault();
  window.scrollTo({top:0, behavior:'smooth'});
});

// Sticky nav shadow
const nav = document.getElementById('nav');
window.addEventListener('scroll', ()=>{
  nav.style.boxShadow = window.scrollY > 8 ? '0 6px 30px rgba(0,0,0,.06)' : 'none';
}, {passive:true});

// command-K quick jump
window.addEventListener('keydown', (e)=>{
  if((e.metaKey || e.ctrlKey) && e.key.toLowerCase()==='k'){
    e.preventDefault();
    const target = document.querySelector('#projects');
    target?.scrollIntoView({behavior:'smooth'});
  }
});
