/**
 * Sentinel AI - Core Application Module
 * Main entry point for the cybersecurity dashboard
 */

(function() {
  'use strict';

  // ========================================
  // APPLICATION STATE
  // ========================================
  const AppState = {
    theme: 'dark',
    sidebarOpen: false,
    sidebarCollapsed: false,
    notifications: [],
    realTimeData: {
      threatsDetected: 24,
      blockedAttacks: 1247,
      activeConnections: 3842,
      systemHealth: 99.9,
      suspiciousIPs: 7,
      firewallAlerts: 12,
      failedLogins: 89,
      malwareDetections: 3
    },
    trafficData: [],
    threats: [],
    logs: [],
    scanResults: [],
    badges: [],
    settings: {
      darkMode: true,
      alertSound: true,
      notifications: true,
      language: 'en',
      voiceEnabled: false,
      voiceRate: 1,
      voicePitch: 1
    }
  };

  // ========================================
  // DOM ELEMENTS CACHE
  // ========================================
  const DOM = {
    loadingOverlay: null,
    alertContainer: null,
    navbar: null,
    mobileToggle: null,
    navMenu: null,
    themeToggle: null,
    sidebar: null,
    sidebarOverlay: null,
    sidebarToggle: null,
    mainContent: null,
    commandPalette: null
  };

  // ========================================
  // INITIALIZATION
  // ========================================
  document.addEventListener('DOMContentLoaded', async () => {
    await initializeApp();
  });

  async function initializeApp() {
    // Cache DOM elements
    cacheDOMElements();
    
    // Load saved settings
    loadSettings();
    
    // Apply theme
    applyTheme(AppState.settings.darkMode ? 'dark' : 'light');
    
    // Initialize components
    initializeNavbar();
    initializeSidebar();
    initializeThemeToggle();
    initializeCommandPalette();
    initializeAlertSystem();
    initializeParticles();
    initializeBinaryRain();
    
    // Start real-time updates
    startRealTimeUpdates();
    
    // Hide loading overlay
    hideLoadingOverlay();
    
    // Initialize page-specific functionality
    initializePageSpecific();
    
    // Announce ready
    console.log('%c🛡️ Sentinel AI Initialized', 'color: #00d4ff; font-size: 16px; font-weight: bold;');
    console.log('%cMonitor. Detect. Defend.', 'color: #7c3aed; font-size: 12px;');
  }

  function cacheDOMElements() {
    DOM.loadingOverlay = document.getElementById('loading-overlay');
    DOM.alertContainer = document.getElementById('alert-container');
    DOM.navbar = document.querySelector('.navbar');
    DOM.mobileToggle = document.querySelector('.navbar__mobile-toggle');
    DOM.navMenu = document.getElementById('navbar-nav');
    DOM.themeToggle = document.getElementById('theme-toggle');
    DOM.sidebar = document.querySelector('.sidebar');
    DOM.sidebarOverlay = document.querySelector('.sidebar-overlay');
    DOM.sidebarToggle = document.querySelector('.sidebar__toggle');
    DOM.mainContent = document.querySelector('.main-content');
    DOM.commandPalette = document.getElementById('command-palette-overlay');
  }

  // ========================================
  // LOADING OVERLAY
  // ========================================
  function hideLoadingOverlay() {
    if (DOM.loadingOverlay) {
      setTimeout(() => {
        DOM.loadingOverlay.classList.add('loading-overlay--hidden');
        setTimeout(() => {
          DOM.loadingOverlay.style.display = 'none';
        }, 300);
      }, 500);
    }
  }

  function showLoadingOverlay(text = 'Loading...', subtext = '') {
    if (DOM.loadingOverlay) {
      DOM.loadingOverlay.style.display = 'flex';
      DOM.loadingOverlay.classList.remove('loading-overlay--hidden');
      const textEl = DOM.loadingOverlay.querySelector('.loading-overlay__text');
      const subtextEl = DOM.loadingOverlay.querySelector('.loading-overlay__subtext');
      if (textEl) textEl.textContent = text;
      if (subtextEl) subtextEl.textContent = subtext;
    }
  }

  // ========================================
  // THEME MANAGEMENT
  // ========================================
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    AppState.theme = theme;
    AppState.settings.darkMode = theme === 'dark';
    saveSettings();
    
    // Update theme toggle icon
    if (DOM.themeToggle) {
      const icon = DOM.themeToggle.querySelector('svg');
      if (icon) {
        icon.innerHTML = theme === 'dark' 
          ? '<circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>'
          : '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>';
      }
    }
  }

  function toggleTheme() {
    const newTheme = AppState.theme === 'dark' ? 'light' : 'dark';
    applyTheme(newTheme);
    showAlert('info', 'Theme Changed', `Switched to ${newTheme} mode`);
  }

  function initializeThemeToggle() {
    if (DOM.themeToggle) {
      DOM.themeToggle.addEventListener('click', toggleTheme);
    }
  }

  // ========================================
  // NAVBAR
  // ========================================
  function initializeNavbar() {
    // Mobile menu toggle
    if (DOM.mobileToggle && DOM.navMenu) {
      DOM.mobileToggle.addEventListener('click', () => {
        const isOpen = DOM.navMenu.classList.toggle('navbar__nav--open');
        DOM.mobileToggle.setAttribute('aria-expanded', isOpen);
        document.body.style.overflow = isOpen ? 'hidden' : '';
      });
    }

    // Close mobile menu on link click
    if (DOM.navMenu) {
      DOM.navMenu.querySelectorAll('.navbar__link').forEach(link => {
        link.addEventListener('click', () => {
          DOM.navMenu.classList.remove('navbar__nav--open');
          DOM.mobileToggle.setAttribute('aria-expanded', 'false');
          document.body.style.overflow = '';
        });
      });
    }

    // Navbar scroll effect
    let lastScroll = 0;
    window.addEventListener('scroll', () => {
      const currentScroll = window.pageYOffset;
      
      if (DOM.navbar) {
        if (currentScroll > 50) {
          DOM.navbar.classList.add('navbar--scrolled');
        } else {
          DOM.navbar.classList.remove('navbar--scrolled');
        }
      }
      
      lastScroll = currentScroll;
    }, { passive: true });

    // Set active nav link based on current page
    setActiveNavLink();
  }

  function setActiveNavLink() {
    const currentPage = document.body.dataset.page || 'landing';
    const pageMap = {
      'landing': 'index.html',
      'dashboard': 'dashboard.html',
      'logs': 'logs.html',
      'chatbot': 'chatbot.html',
      'analytics': 'analytics.html',
      'scan': 'scan.html',
      'settings': 'settings.html'
    };
    
    const activeHref = pageMap[currentPage] || 'index.html';
    document.querySelectorAll('.navbar__link').forEach(link => {
      if (link.getAttribute('href') === activeHref) {
        link.setAttribute('aria-current', 'page');
      } else {
        link.removeAttribute('aria-current');
      }
    });
  }

  // ========================================
  // SIDEBAR
  // ========================================
  function initializeSidebar() {
    // Sidebar toggle (desktop collapse)
    const sidebarToggleBtn = document.querySelector('.sidebar__toggle');
    if (sidebarToggleBtn && DOM.sidebar) {
      sidebarToggleBtn.addEventListener('click', () => {
        DOM.sidebar.classList.toggle('sidebar--collapsed');
        AppState.sidebarCollapsed = DOM.sidebar.classList.contains('sidebar--collapsed');
        saveSettings();
      });
    }

    // Mobile sidebar overlay
    if (DOM.sidebarOverlay) {
      DOM.sidebarOverlay.addEventListener('click', closeSidebar);
    }

    // Sidebar navigation items
    document.querySelectorAll('.sidebar__nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        // Don't prevent default for links
        if (item.tagName === 'A') return;
        
        document.querySelectorAll('.sidebar__nav-item').forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        
        // Close mobile sidebar on selection
        if (window.innerWidth <= 1200) {
          closeSidebar();
        }
      });
    });
  }

  function openSidebar() {
    if (DOM.sidebar) {
      DOM.sidebar.classList.add('sidebar--open');
      AppState.sidebarOpen = true;
    }
    if (DOM.sidebarOverlay) {
      DOM.sidebarOverlay.classList.add('sidebar-overlay--open');
    }
    document.body.style.overflow = 'hidden';
  }

  function closeSidebar() {
    if (DOM.sidebar) {
      DOM.sidebar.classList.remove('sidebar--open');
      AppState.sidebarOpen = false;
    }
    if (DOM.sidebarOverlay) {
      DOM.sidebarOverlay.classList.remove('sidebar-overlay--open');
    }
    document.body.style.overflow = '';
  }

  // ========================================
  // COMMAND PALETTE
  // ========================================
  function initializeCommandPalette() {
    // Create command palette HTML
    const paletteHTML = `
      <div id="command-palette-overlay" class="modal-overlay" role="dialog" aria-modal="true" aria-label="Command Palette">
        <div class="modal modal--command-palette">
          <div class="modal__header">
            <h2 class="modal__title">Command Palette</h2>
            <kbd class="command-palette__shortcut">⌘K</kbd>
          </div>
          <div class="modal__body">
            <div class="command-palette__search">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              </svg>
              <input type="text" class="command-palette__input form-input" placeholder="Type a command or search..." autocomplete="off" spellcheck="false">
              <kbd class="command-palette__shortcut">Enter</kbd>
            </div>
            <div class="command-palette__results" role="listbox" aria-label="Commands"></div>
            <div class="command-palette__help">
              <kbd>↑</kbd><kbd>↓</kbd> Navigate • <kbd>Enter</kbd> Select • <kbd>Esc</kbd> Close
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', paletteHTML);
    
    const overlay = document.getElementById('command-palette-overlay');
    const input = overlay.querySelector('.command-palette__input');
    const results = overlay.querySelector('.command-palette__results');
    
    const commands = [
      { id: 'dashboard', label: 'Go to Dashboard', description: 'Open main security dashboard', action: () => navigateTo('dashboard.html'), icon: '📊', keys: '⌘1' },
      { id: 'logs', label: 'View Security Logs', description: 'Analyze threat logs and events', action: () => navigateTo('logs.html'), icon: '📋', keys: '⌘2' },
      { id: 'chatbot', label: 'AI Assistant', description: 'Chat with security AI assistant', action: () => navigateTo('chatbot.html'), icon: '🤖', keys: '⌘3' },
      { id: 'analytics', label: 'Analytics', description: 'View threat analytics and trends', action: () => navigateTo('analytics.html'), icon: '📈', keys: '⌘4' },
      { id: 'scan', label: 'Security Scan', description: 'Run penetration test simulation', action: () => navigateTo('scan.html'), icon: '🔍', keys: '⌘5' },
      { id: 'settings', label: 'Settings', description: 'Configure Sentinel AI', action: () => navigateTo('settings.html'), icon: '⚙️', keys: '⌘,' },
      { id: 'theme', label: 'Toggle Theme', description: 'Switch between dark/light mode', action: toggleTheme, icon: '🌓', keys: '⌘⇧T' },
      { id: 'scan-quick', label: 'Quick Security Scan', description: 'Run immediate vulnerability scan', action: runQuickScan, icon: '⚡', keys: '⌘⇧S' },
      { id: 'alerts', label: 'View Alerts', description: 'Show recent security alerts', action: showAlertsPanel, icon: '🚨', keys: '⌘⇧A' },
      { id: 'export', label: 'Export Report', description: 'Generate security report', action: exportReport, icon: '📄', keys: '⌘E' },
      { id: 'help', label: 'Keyboard Shortcuts', description: 'Show all available shortcuts', action: showShortcuts, icon: '⌨️', keys: '⌘/' },
      { id: 'voice', label: 'Toggle Voice Assistant', description: 'Enable/disable voice commands', action: toggleVoiceAssistant, icon: '🎤', keys: '⌘⇧V' }
    ];
    
    let selectedIndex = 0;
    let filteredCommands = commands;
    
    function renderResults() {
      results.innerHTML = filteredCommands.map((cmd, index) => `
        <div class="command-palette__item ${index === selectedIndex ? 'command-palette__item--selected' : ''}" 
             data-command-id="${cmd.id}" role="option" aria-selected="${index === selectedIndex}">
          <span class="command-palette__item-icon">${cmd.icon}</span>
          <div class="command-palette__item-content">
            <span class="command-palette__item-label">${cmd.label}</span>
            <span class="command-palette__item-description">${cmd.description}</span>
          </div>
          <kbd class="command-palette__item-keys">${cmd.keys}</kbd>
        </div>
      `).join('');
    }
    
    function filterCommands(query) {
      const q = query.toLowerCase().trim();
      if (!q) {
        filteredCommands = commands;
      } else {
        filteredCommands = commands.filter(cmd => 
          cmd.label.toLowerCase().includes(q) ||
          cmd.description.toLowerCase().includes(q) ||
          cmd.id.toLowerCase().includes(q)
        );
      }
      selectedIndex = 0;
      renderResults();
    }
    
    function selectCommand(index) {
      if (index >= 0 && index < filteredCommands.length) {
        selectedIndex = index;
        renderResults();
      }
    }
    
    function executeCommand(index) {
      const cmd = filteredCommands[index];
      if (cmd) {
        closeCommandPalette();
        cmd.action();
      }
    }
    
    function openCommandPalette() {
      overlay.classList.add('modal-overlay--open');
      input.value = '';
      filterCommands('');
      setTimeout(() => input.focus(), 100);
      document.body.style.overflow = 'hidden';
    }
    
    function closeCommandPalette() {
      overlay.classList.remove('modal-overlay--open');
      document.body.style.overflow = '';
    }
    
    // Event listeners
    document.addEventListener('keydown', (e) => {
      // Open with Cmd/Ctrl + K
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        openCommandPalette();
      }
      
      // Close with Escape
      if (e.key === 'Escape' && overlay.classList.contains('modal-overlay--open')) {
        closeCommandPalette();
      }
      
      // Navigation within palette
      if (overlay.classList.contains('modal-overlay--open')) {
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          selectCommand(Math.min(selectedIndex + 1, filteredCommands.length - 1));
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          selectCommand(Math.max(selectedIndex - 1, 0));
        } else if (e.key === 'Enter') {
          e.preventDefault();
          executeCommand(selectedIndex);
        }
      }
    });
    
    input.addEventListener('input', (e) => filterCommands(e.target.value));
    
    results.addEventListener('click', (e) => {
      const item = e.target.closest('.command-palette__item');
      if (item) {
        const index = Array.from(results.children).indexOf(item);
        executeCommand(index);
      }
    });
    
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeCommandPalette();
    });
  }

  // ========================================
  // ALERT SYSTEM
  // ========================================
  function initializeAlertSystem() {
    // Alert container already exists in HTML
    // Add sound context for notifications
    if (AppState.settings.alertSound) {
      // Preload notification sound
      const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT');
      AppState.notificationSound = audio;
    }
  }

  function showAlert(type, title, message, actions = [], duration = 5000) {
    if (!DOM.alertContainer) return;
    
    const alertId = 'alert-' + Date.now();
    const alertEl = document.createElement('div');
    alertEl.id = alertId;
    alertEl.className = `alert alert--${type}`;
    alertEl.setAttribute('role', 'alert');
    alertEl.setAttribute('aria-live', 'polite');
    
    const icons = {
      critical: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>',
      warning: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>',
      info: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
      success: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>'
    };
    
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    alertEl.innerHTML = `
      <div class="alert__icon">${icons[type] || icons.info}</div>
      <div class="alert__content">
        <div class="alert__title">${escapeHtml(title)}</div>
        <div class="alert__message">${escapeHtml(message)}</div>
        <div class="alert__time">${timeStr}</div>
        ${actions.length > 0 ? `
          <div class="alert__actions">
            ${actions.map(a => `<button class="btn btn--sm btn--${a.variant || 'ghost'}" data-action="${escapeHtml(a.action)}">${escapeHtml(a.label)}</button>`).join('')}
          </div>
        ` : ''}
      </div>
      <button class="alert__close" aria-label="Dismiss alert">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
      </button>
      <div class="alert__progress" style="animation-duration: ${duration}ms"></div>
    `;
    
    DOM.alertContainer.appendChild(alertEl);
    
    // Trigger animation
    requestAnimationFrame(() => {
      alertEl.classList.add('alert--visible');
    });
    
    // Play sound
    if (AppState.settings.alertSound && AppState.notificationSound) {
      AppState.notificationSound.currentTime = 0;
      AppState.notificationSound.play().catch(() => {});
    }
    
    // Auto remove
    const removeTimeout = setTimeout(() => removeAlert(alertId), duration);
    
    // Close button
    alertEl.querySelector('.alert__close').addEventListener('click', () => {
      clearTimeout(removeTimeout);
      removeAlert(alertId);
    });
    
    // Action buttons
    alertEl.querySelectorAll('[data-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        const action = btn.dataset.action;
        handleAlertAction(action);
        clearTimeout(removeTimeout);
        removeAlert(alertId);
      });
    });
    
    // Store for management
    AppState.notifications.push({ id: alertId, element: alertEl, timeout: removeTimeout });
    
    // Limit notifications
    if (AppState.notifications.length > 5) {
      const oldest = AppState.notifications.shift();
      clearTimeout(oldest.timeout);
      removeAlert(oldest.id);
    }
  }

  function removeAlert(id) {
    const alertEl = document.getElementById(id);
    if (alertEl) {
      alertEl.classList.add('alert--removing');
      setTimeout(() => {
        alertEl.remove();
        AppState.notifications = AppState.notifications.filter(n => n.id !== id);
      }, 300);
    }
  }

  function handleAlertAction(action) {
    switch (action) {
      case 'view-dashboard':
        navigateTo('dashboard.html');
        break;
      case 'view-logs':
        navigateTo('logs.html');
        break;
      case 'block-ip':
        showAlert('info', 'Action Queued', 'IP blocking initiated');
        break;
      case 'run-scan':
        navigateTo('scan.html');
        break;
      default:
        console.log('Alert action:', action);
    }
  }

  function showAlertsPanel() {
    showAlert('info', 'Alerts Panel', 'Recent alerts would be displayed here', [
      { label: 'View All', action: 'view-dashboard', variant: 'primary' }
    ]);
  }

  // ========================================
  // PARTICLES & BINARY RAIN
  // ========================================
  function initializeParticles() {
    const container = document.querySelector('.particles-container');
    if (!container) return;
    
    const particleCount = window.innerWidth < 768 ? 30 : 60;
    
    for (let i = 0; i < particleCount; i++) {
      createParticle(container);
    }
  }

  function createParticle(container) {
    const particle = document.createElement('div');
    particle.className = 'particle';
    particle.style.cssText = `
      position: absolute;
      width: ${Math.random() * 3 + 1}px;
      height: ${Math.random() * 3 + 1}px;
      background: ${Math.random() > 0.5 ? 'var(--neon-blue)' : 'var(--neon-purple)'};
      border-radius: 50%;
      opacity: ${Math.random() * 0.5 + 0.1};
      left: ${Math.random() * 100}%;
      top: ${Math.random() * 100}%;
      pointer-events: none;
      animation: particleFloat ${Math.random() * 20 + 10}s linear infinite;
      animation-delay: ${Math.random() * 5}s;
    `;
    
    container.appendChild(particle);
    
    // Clean up after animation
    setTimeout(() => {
      if (particle.parentNode) {
        particle.remove();
        createParticle(container);
      }
    }, (Math.random() * 20 + 10) * 1000);
  }

  // Add particle animation keyframes dynamically
  const particleStyle = document.createElement('style');
  particleStyle.textContent = `
    @keyframes particleFloat {
      0% { transform: translateY(0) translateX(0); opacity: 0; }
      10% { opacity: 0.5; }
      90% { opacity: 0.5; }
      100% { transform: translateY(-100vh) translateX(${Math.random() * 200 - 100}px); opacity: 0; }
    }
  `;
  document.head.appendChild(particleStyle);

  function initializeBinaryRain() {
    const container = document.querySelector('.binary-rain');
    if (!container) return;
    
    const columnCount = Math.floor(window.innerWidth / 30);
    
    for (let i = 0; i < columnCount; i++) {
      createBinaryColumn(container, i);
    }
  }

  function createBinaryColumn(container, index) {
    const column = document.createElement('div');
    column.className = 'binary-column';
    column.style.cssText = `
      position: absolute;
      top: -100%;
      left: ${index * 30 + Math.random() * 10}px;
      font-family: var(--font-mono);
      font-size: ${Math.random() * 8 + 10}px;
      color: rgba(0, 212, 255, ${Math.random() * 0.1 + 0.02});
      white-space: nowrap;
      pointer-events: none;
      animation: binaryFall ${Math.random() * 15 + 10}s linear infinite;
      animation-delay: ${Math.random() * 5}s;
    `;
    
    // Generate binary string
    let binary = '';
    const length = Math.floor(Math.random() * 20 + 10);
    for (let i = 0; i < length; i++) {
      binary += Math.random() > 0.5 ? '1' : '0';
      if (i < length - 1) binary += '<br>';
    }
    column.innerHTML = binary;
    
    container.appendChild(column);
    
    // Clean up
    setTimeout(() => {
      if (column.parentNode) {
        column.remove();
        createBinaryColumn(container, index);
      }
    }, (Math.random() * 15 + 10) * 1000);
  }

  // Add binary rain animation
  const binaryStyle = document.createElement('style');
  binaryStyle.textContent = `
    @keyframes binaryFall {
      0% { transform: translateY(0); opacity: 0; }
      10% { opacity: 1; }
      90% { opacity: 1; }
      100% { transform: translateY(200vh); opacity: 0; }
    }
  `;
  document.head.appendChild(binaryStyle);

  // ========================================
  // REAL-TIME UPDATES
  // ========================================
  function startRealTimeUpdates() {
    // Update metrics every 2-5 seconds
    setInterval(updateMetrics, 3000 + Math.random() * 2000);
    
    // Simulate traffic updates
    setInterval(simulateTraffic, 1000 + Math.random() * 2000);
    
    // Simulate threat detection
    setInterval(simulateThreatDetection, 10000 + Math.random() * 20000);
    
    // Update charts if on dashboard/analytics
    if (typeof updateCharts === 'function') {
      setInterval(updateCharts, 5000);
    }
  }

  function updateMetrics() {
    // Simulate metric changes
    const variance = () => Math.floor(Math.random() * 5) - 2;
    
    AppState.realTimeData.threatsDetected = Math.max(0, AppState.realTimeData.threatsDetected + variance());
    AppState.realTimeData.blockedAttacks += Math.floor(Math.random() * 3) + 1;
    AppState.realTimeData.activeConnections += variance() * 10;
    AppState.realTimeData.activeConnections = Math.max(1000, AppState.realTimeData.activeConnections);
    AppState.realTimeData.systemHealth = Math.min(100, Math.max(95, AppState.realTimeData.systemHealth + (Math.random() - 0.5) * 0.2));
    AppState.realTimeData.suspiciousIPs = Math.max(0, AppState.realTimeData.suspiciousIPs + variance());
    AppState.realTimeData.firewallAlerts = Math.max(0, AppState.realTimeData.firewallAlerts + variance());
    AppState.realTimeData.failedLogins += Math.floor(Math.random() * 2);
    AppState.realTimeData.malwareDetections = Math.max(0, AppState.realTimeData.malwareDetections + variance());
    
    // Update DOM elements
    updateMetricDisplays();
  }

  function updateMetricDisplays() {
    const metrics = AppState.realTimeData;
    
    // Update any element with data-metric attribute
    document.querySelectorAll('[data-metric]').forEach(el => {
      const metric = el.dataset.metric;
      if (metrics[metric] !== undefined) {
        let value = metrics[metric];
        if (metric === 'systemHealth') {
          value = value.toFixed(1) + '%';
        } else if (typeof value === 'number' && value > 999) {
          value = formatNumber(value);
        }
        el.textContent = value;
      }
    });
    
    // Update stat cards
    const statMap = {
      'stat-critical': 'threatsDetected',
      'stat-high': 'firewallAlerts',
      'stat-blocked': 'blockedAttacks',
      'stat-uptime': 'systemHealth'
    };
    
    Object.entries(statMap).forEach(([id, metric]) => {
      const el = document.getElementById(id);
      if (el && metrics[metric] !== undefined) {
        let value = metrics[metric];
        if (metric === 'systemHealth') {
          value = value.toFixed(2) + '%';
        } else if (typeof value === 'number' && value > 999) {
          value = formatNumber(value);
        }
        el.textContent = value;
      }
    });
  }

  function simulateTraffic() {
    const protocols = ['TCP', 'UDP', 'ICMP', 'HTTP', 'HTTPS', 'SSH', 'DNS', 'TLS'];
    const statuses = ['Allowed', 'Blocked', 'Suspicious', 'Monitored'];
    const ports = [22, 23, 25, 53, 80, 110, 143, 443, 465, 587, 993, 995, 3306, 5432, 8080, 8443];
    
    const srcIP = generateRandomIP(true);
    const dstIP = generateRandomIP(false);
    const protocol = protocols[Math.floor(Math.random() * protocols.length)];
    const port = ports[Math.floor(Math.random() * ports.length)];
    const status = statuses[Math.floor(Math.random() * statuses.length)];
    const size = Math.floor(Math.random() * 1500) + 64;
    
    const trafficEntry = {
      timestamp: new Date(),
      srcIP,
      dstIP,
      protocol,
      port,
      status,
      size,
      bytes: formatBytes(size)
    };
    
    AppState.trafficData.unshift(trafficEntry);
    if (AppState.trafficData.length > 100) AppState.trafficData.pop();
    
    // Update traffic display if on dashboard
    if (typeof updateTrafficDisplay === 'function') {
      updateTrafficDisplay(trafficEntry);
    }
  }

  function simulateThreatDetection() {
    const threatTypes = [
      { type: 'Port Scanning', severity: 'medium', description: 'Multiple port connection attempts detected' },
      { type: 'Brute Force', severity: 'high', description: 'Repeated failed authentication attempts' },
      { type: 'SQL Injection', severity: 'critical', description: 'Malicious SQL payload detected in request' },
      { type: 'DDoS Attempt', severity: 'critical', description: 'Unusual traffic spike from single source' },
      { type: 'Malware Behavior', severity: 'high', description: 'Suspicious file execution pattern' },
      { type: 'Suspicious Login', severity: 'medium', description: 'Login from unusual location/device' },
      { type: 'Data Exfiltration', severity: 'critical', description: 'Large outbound data transfer detected' },
      { type: 'C2 Communication', severity: 'high', description: 'Command & control beacon detected' }
    ];
    
    const threat = threatTypes[Math.floor(Math.random() * threatTypes.length)];
    const srcIP = generateRandomIP(false);
    const confidence = Math.floor(Math.random() * 20) + 80;
    
    const threatEntry = {
      id: 'threat-' + Date.now(),
      timestamp: new Date(),
      type: threat.type,
      severity: threat.severity,
      description: threat.description,
      sourceIP: srcIP,
      sourceCountry: getRandomCountry(),
      confidence,
      status: 'active',
      mitre: getRandomMitre()
    };
    
    AppState.threats.unshift(threatEntry);
    if (AppState.threats.length > 50) AppState.threats.pop();
    
    // Show alert for critical/high threats
    if (threat.severity === 'critical' || threat.severity === 'high') {
      showAlert(threat.severity === 'critical' ? 'critical' : 'warning', 
        `${threat.type} Detected`, 
        `${threat.description} from ${srcIP} (${threat.sourceCountry})`,
        [
          { label: 'Investigate', action: 'view-logs', variant: 'primary' },
          { label: 'Block IP', action: 'block-ip', variant: 'danger' }
        ],
        10000
      );
    }
    
    // Update threat display if on dashboard
    if (typeof updateThreatDisplay === 'function') {
      updateThreatDisplay(threatEntry);
    }
  }

  // ========================================
  // UTILITY FUNCTIONS
  // ========================================
  function generateRandomIP(internal = false) {
    if (internal) {
      // Private IP ranges
      const ranges = [
        [10, 0, 0, 0, 10, 255, 255, 255],
        [172, 16, 0, 0, 172, 31, 255, 255],
        [192, 168, 0, 0, 192, 168, 255, 255]
      ];
      const range = ranges[Math.floor(Math.random() * ranges.length)];
      return `${range[0]}.${Math.floor(Math.random() * (range[4] - range[0] + 1)) + range[0]}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
    } else {
      // Public IP (avoid reserved ranges)
      return `${Math.floor(Math.random() * 223) + 1}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
    }
  }

  function getRandomCountry() {
    const countries = [
      { code: 'CN', name: 'China' },
      { code: 'RU', name: 'Russia' },
      { code: 'US', name: 'United States' },
      { code: 'BR', name: 'Brazil' },
      { code: 'IN', name: 'India' },
      { code: 'KR', name: 'South Korea' },
      { code: 'VN', name: 'Vietnam' },
      { code: 'IR', name: 'Iran' },
      { code: 'TR', name: 'Turkey' },
      { code: 'DE', name: 'Germany' }
    ];
    return countries[Math.floor(Math.random() * countries.length)];
  }

  function getRandomMitre() {
    const techniques = [
      'T1590.005', 'T1110.001', 'T1190', 'T1499', 'T1059.001',
      'T1071.001', 'T1041', 'T1071.004', 'T1003.001', 'T1555.003'
    ];
    return techniques[Math.floor(Math.random() * techniques.length)];
  }

  function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  }

  function formatBytes(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function navigateTo(url) {
    window.location.href = url;
  }

  function runQuickScan() {
    showAlert('info', 'Quick Scan Started', 'Security scan initiated. Results will appear in the Scan page.', [
      { label: 'View Scan', action: 'view-scan', variant: 'primary' }
    ]);
    navigateTo('scan.html');
  }

  function exportReport() {
    showAlert('success', 'Report Generated', 'Security report has been generated and downloaded.', [
      { label: 'Download', action: 'download-report', variant: 'primary' }
    ]);
  }

  function showShortcuts() {
    const shortcuts = [
      { keys: '⌘K', desc: 'Open Command Palette' },
      { keys: '⌘1-5', desc: 'Navigate to pages' },
      { keys: '⌘⇧T', desc: 'Toggle Theme' },
      { keys: '⌘⇧S', desc: 'Quick Security Scan' },
      { keys: '⌘⇧A', desc: 'View Alerts' },
      { keys: '⌘E', desc: 'Export Report' },
      { keys: '⌘/', desc: 'Show Shortcuts' },
      { keys: '⌘⇧V', desc: 'Toggle Voice Assistant' },
      { keys: 'Esc', desc: 'Close modals/panels' }
    ];
    
    const modalHTML = `
      <div class="modal-overlay modal-overlay--open" id="shortcuts-modal">
        <div class="modal">
          <div class="modal__header">
            <h2 class="modal__title">Keyboard Shortcuts</h2>
            <button class="modal__close" id="shortcuts-close" aria-label="Close">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
          </div>
          <div class="modal__body">
            <div class="shortcuts-list">
              ${shortcuts.map(s => `
                <div class="shortcut-item">
                  <kbd class="shortcut-keys">${s.keys}</kbd>
                  <span class="shortcut-desc">${s.desc}</span>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    const modal = document.getElementById('shortcuts-modal');
    const closeBtn = document.getElementById('shortcuts-close');
    
    function close() {
      modal.classList.remove('modal-overlay--open');
      setTimeout(() => modal.remove(), 300);
    }
    
    closeBtn.addEventListener('click', close);
    modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
    document.addEventListener('keydown', function esc(e) {
      if (e.key === 'Escape') {
        close();
        document.removeEventListener('keydown', esc);
      }
    });
  }

  function toggleVoiceAssistant() {
    AppState.settings.voiceEnabled = !AppState.settings.voiceEnabled;
    saveSettings();
    showAlert(AppState.settings.voiceEnabled ? 'success' : 'info', 
      AppState.settings.voiceEnabled ? 'Voice Assistant Enabled' : 'Voice Assistant Disabled',
      AppState.settings.voiceEnabled ? 'Say "Hey Sentinel" to activate' : 'Voice commands are now disabled'
    );
  }

  // ========================================
  // SETTINGS PERSISTENCE
  // ========================================
  function saveSettings() {
    try {
      localStorage.setItem('sentinel-settings', JSON.stringify(AppState.settings));
      localStorage.setItem('sentinel-sidebar-collapsed', JSON.stringify(AppState.sidebarCollapsed));
    } catch (e) {
      console.warn('Failed to save settings:', e);
    }
  }

  function loadSettings() {
    try {
      const saved = localStorage.getItem('sentinel-settings');
      if (saved) {
        AppState.settings = { ...AppState.settings, ...JSON.parse(saved) };
      }
      const sidebarSaved = localStorage.getItem('sentinel-sidebar-collapsed');
      if (sidebarSaved) {
        AppState.sidebarCollapsed = JSON.parse(sidebarSaved);
      }
    } catch (e) {
      console.warn('Failed to load settings:', e);
    }
  }

  // ========================================
  // PAGE-SPECIFIC INITIALIZATION
  // ========================================
  function initializePageSpecific() {
    const page = document.body.dataset.page;
    
    switch (page) {
      case 'landing':
        if (typeof initializeLanding === 'function') initializeLanding();
        break;
      case 'dashboard':
        if (typeof initializeDashboard === 'function') initializeDashboard();
        break;
      case 'logs':
        if (typeof initializeLogs === 'function') initializeLogs();
        break;
      case 'chatbot':
        if (typeof initializeChatbot === 'function') initializeChatbot();
        break;
      case 'analytics':
        if (typeof initializeAnalytics === 'function') initializeAnalytics();
        break;
      case 'scan':
        if (typeof initializeScan === 'function') initializeScan();
        break;
      case 'settings':
        if (typeof initializeSettings === 'function') initializeSettings();
        break;
    }
  }

  // ========================================
  // PUBLIC API
  // ========================================
  window.SentinelAI = {
    // State
    getState: () => AppState,
    
    // Alerts
    showAlert,
    removeAlert,
    
    // Theme
    applyTheme,
    toggleTheme,
    
    // Navigation
    navigateTo,
    openSidebar,
    closeSidebar,
    
    // Data
    getTrafficData: () => AppState.trafficData,
    getThreats: () => AppState.threats,
    getMetrics: () => AppState.realTimeData,
    
    // Settings
    saveSettings,
    loadSettings,
    getSettings: () => AppState.settings,
    updateSettings: (newSettings) => {
      AppState.settings = { ...AppState.settings, ...newSettings };
      saveSettings();
    },
    
    // Utilities
    formatNumber,
    formatBytes,
    escapeHtml,
    generateRandomIP,
    
    // Commands
    runQuickScan,
    exportReport,
    showShortcuts,
    toggleVoiceAssistant
  };

  // ========================================
  // SERVICE WORKER REGISTRATION
  // ========================================
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch(() => {
        // SW registration failed, continue without it
      });
    });
  }

})();