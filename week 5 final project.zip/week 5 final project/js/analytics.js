/* ============================================================
   SENTINELAI - Analytics Dashboard (Chart.js)
   ============================================================ */

let chartsInitialized = false;
let chartInstances = {};

const chartColors = {
  blue: 'rgba(0, 212, 255, 0.8)',
  blueLight: 'rgba(0, 212, 255, 0.15)',
  red: 'rgba(255, 0, 68, 0.8)',
  redLight: 'rgba(255, 0, 68, 0.15)',
  green: 'rgba(0, 255, 136, 0.8)',
  greenLight: 'rgba(0, 255, 136, 0.15)',
  yellow: 'rgba(255, 204, 0, 0.8)',
  yellowLight: 'rgba(255, 204, 0, 0.15)',
  purple: 'rgba(170, 68, 255, 0.8)',
  purpleLight: 'rgba(170, 68, 255, 0.15)',
  orange: 'rgba(255, 102, 0, 0.8)',
  orangeLight: 'rgba(255, 102, 0, 0.15)',
};

function initCharts() {
  if (chartsInitialized) return;
  if (typeof Chart === 'undefined') {
    // Chart.js not loaded yet, retry
    setTimeout(initCharts, 500);
    return;
  }

  Chart.defaults.color = '#8899bb';
  Chart.defaults.borderColor = 'rgba(255,255,255,0.05)';
  Chart.defaults.font.family = "'Inter', sans-serif";

  createAttackTypeChart();
  createDailyThreatChart();
  createMonthlyTrendChart();
  createSeverityChart();

  chartsInitialized = true;
}

function createChartConfig(type, data, options = {}) {
  return {
    type,
    data,
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          labels: {
            color: '#8899bb',
            font: { size: 11 },
            padding: 12,
          },
        },
        tooltip: {
          backgroundColor: 'rgba(2, 6, 23, 0.95)',
          titleColor: '#e8f0ff',
          bodyColor: '#8899bb',
          borderColor: 'rgba(0, 212, 255, 0.2)',
          borderWidth: 1,
          padding: 12,
          cornerRadius: 8,
        },
      },
      scales: {
        x: {
          grid: { color: 'rgba(255,255,255,0.03)', drawBorder: false },
          ticks: { color: '#556688', maxRotation: 45 },
        },
        y: {
          grid: { color: 'rgba(255,255,255,0.03)', drawBorder: false },
          ticks: { color: '#556688' },
          beginAtZero: true,
        },
      },
      ...options,
    },
  };
}

function createAttackTypeChart() {
  const ctx = document.getElementById('attackTypeChart');
  if (!ctx) return;

  if (chartInstances.attackType) chartInstances.attackType.destroy();

  const config = createChartConfig('doughnut', {
    labels: ['DDoS', 'Brute Force', 'SQL Injection', 'Phishing', 'Malware', 'Port Scan'],
    datasets: [{
      data: [35, 25, 18, 12, 7, 3],
      backgroundColor: [
        chartColors.red,
        chartColors.orange,
        chartColors.yellow,
        chartColors.blue,
        chartColors.purple,
        chartColors.green,
      ],
      borderColor: 'rgba(2, 6, 23, 0.8)',
      borderWidth: 2,
      hoverOffset: 8,
    }],
  }, {
    cutout: '65%',
    plugins: {
      legend: { position: 'right' },
    },
  });

  chartInstances.attackType = new Chart(ctx, config);
}

function createDailyThreatChart() {
  const ctx = document.getElementById('dailyThreatChart');
  if (!ctx) return;

  if (chartInstances.dailyThreat) chartInstances.dailyThreat.destroy();

  const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const threats = [145, 189, 234, 178, 312, 256, 198];
  const blocked = [132, 170, 215, 160, 290, 230, 180];

  const config = createChartConfig('line', {
    labels,
    datasets: [
      {
        label: 'Threats Detected',
        data: threats,
        borderColor: chartColors.red,
        backgroundColor: chartColors.redLight,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: chartColors.red,
        pointBorderColor: 'rgba(2, 6, 23, 0.8)',
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
        borderWidth: 2,
      },
      {
        label: 'Blocked',
        data: blocked,
        borderColor: chartColors.green,
        backgroundColor: chartColors.greenLight,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: chartColors.green,
        pointBorderColor: 'rgba(2, 6, 23, 0.8)',
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
        borderWidth: 2,
      },
    ],
  }, {
    interaction: {
      intersect: false,
      mode: 'index',
    },
  });

  chartInstances.dailyThreat = new Chart(ctx, config);
}

function createMonthlyTrendChart() {
  const ctx = document.getElementById('monthlyTrendChart');
  if (!ctx) return;

  if (chartInstances.monthlyTrend) chartInstances.monthlyTrend.destroy();

  const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const data = [1200, 1350, 1100, 1450, 1600, 1550, 1800, 2100, 1950, 2200, 2400, 2600];

  const config = createChartConfig('bar', {
    labels,
    datasets: [{
      label: 'Monthly Attacks',
      data,
      backgroundColor: data.map(v =>
        v > 2000 ? chartColors.red :
        v > 1600 ? chartColors.orange :
        v > 1300 ? chartColors.yellow :
        chartColors.blue
      ),
      borderRadius: 4,
      borderSkipped: false,
    }],
  }, {
    plugins: { legend: { display: false } },
  });

  chartInstances.monthlyTrend = new Chart(ctx, config);
}

function createSeverityChart() {
  const ctx = document.getElementById('severityChart');
  if (!ctx) return;

  if (chartInstances.severity) chartInstances.severity.destroy();

  const config = createChartConfig('radar', {
    labels: ['Critical', 'High', 'Medium', 'Low', 'Info', 'Warning'],
    datasets: [
      {
        label: 'Current Period',
        data: [45, 68, 92, 120, 200, 85],
        borderColor: chartColors.blue,
        backgroundColor: chartColors.blueLight,
        pointBackgroundColor: chartColors.blue,
        pointBorderColor: 'rgba(2, 6, 23, 0.8)',
        pointBorderWidth: 2,
        pointRadius: 4,
        borderWidth: 2,
      },
      {
        label: 'Previous Period',
        data: [30, 55, 78, 105, 180, 70],
        borderColor: chartColors.purple,
        backgroundColor: chartColors.purpleLight,
        pointBackgroundColor: chartColors.purple,
        pointBorderColor: 'rgba(2, 6, 23, 0.8)',
        pointBorderWidth: 2,
        pointRadius: 4,
        borderWidth: 2,
      },
    ],
  }, {
    scales: {
      r: {
        grid: { color: 'rgba(255,255,255,0.05)' },
        angleLines: { color: 'rgba(255,255,255,0.05)' },
        pointLabels: { color: '#8899bb', font: { size: 11 } },
        ticks: {
          backdropColor: 'transparent',
          color: '#556688',
          stepSize: 50,
        },
      },
    },
  });

  chartInstances.severity = new Chart(ctx, config);
}
