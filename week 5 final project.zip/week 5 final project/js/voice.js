/* ============================================================
   SENTINELAI - Voice Security Assistant
   ============================================================ */

let recognition = null;
let isListening = false;
let voiceSynthesis = window.speechSynthesis;

function initVoiceAssistant() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    document.querySelector('.voice-status').textContent = 'Voice recognition not supported in this browser';
    return;
  }

  recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = 'en-US';

  recognition.onresult = async (event) => {
    const transcript = event.results[0][0].transcript;
    document.querySelector('.voice-status').textContent = `You said: "${transcript}"`;
    processVoiceQuery(transcript);
  };

  recognition.onerror = (event) => {
    document.querySelector('.voice-status').textContent = `Error: ${event.error}`;
    stopListening();
  };

  recognition.onend = () => {
    stopListening();
  };
}

function toggleListening() {
  if (isListening) {
    stopListening();
  } else {
    startListening();
  }
}

function startListening() {
  if (!recognition) {
    initVoiceAssistant();
    if (!recognition) return;
  }

  try {
    recognition.start();
    isListening = true;
    const mic = document.querySelector('.voice-mic');
    mic.classList.add('listening');
    document.querySelector('.voice-status').textContent = 'Listening... Speak now';

    // Add ripple effect
    const ripple = document.createElement('div');
    ripple.className = 'ripple';
    mic.appendChild(ripple);
    setTimeout(() => ripple.remove(), 1500);
  } catch (e) {
    console.error('Voice error:', e);
  }
}

function stopListening() {
  isListening = false;
  const mic = document.querySelector('.voice-mic');
  if (mic) mic.classList.remove('listening');
  if (document.querySelector('.voice-status')) {
    document.querySelector('.voice-status').textContent = 'Click the microphone to ask a question';
  }
  if (recognition) {
    try { recognition.stop(); } catch(e) { /* silent */ }
  }
}

async function processVoiceQuery(transcript) {
  const output = document.querySelector('.voice-output');
  if (!output) return;

  output.innerHTML = '<div class="loading-spinner"></div> Processing...';

  const response = await callAI(`You are a cybersecurity expert. Answer this question concisely and conversationally: ${transcript}`);

  output.innerHTML = `
    <div style="margin-bottom: 0.75rem;">
      <strong style="color: var(--neon-blue);">You:</strong> ${transcript}
    </div>
    <div>
      <strong style="color: var(--neon-green);">AI:</strong> ${response}
    </div>
  `;

  // Speak the response
  if (settingVoice) {
    speakText(response);
  }
}

function speakText(text) {
  if (!voiceSynthesis) return;

  // Cancel any ongoing speech
  voiceSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1.0;
  utterance.pitch = 1.0;
  utterance.volume = 1.0;

  // Try to find a good voice
  const voices = voiceSynthesis.getVoices();
  const preferredVoice = voices.find(v => v.lang.startsWith('en') && v.name.includes('Google')) ||
                         voices.find(v => v.lang.startsWith('en-US')) ||
                         voices[0];
  if (preferredVoice) utterance.voice = preferredVoice;

  voiceSynthesis.speak(utterance);
}

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
  // Voice recognition will be initialized on first use
  const mic = document.querySelector('.voice-mic');
  if (mic) {
    mic.addEventListener('click', toggleListening);
  }
});
