/* ============================================================
   SENTINELAI - Main Application Script
   ============================================================ */

let uptimeSeconds = 0;
let totalPackets = 0;
let threatCount = 0;
let settingAlerts = true;
let settingSound = true;
let settingVoice = true;
let settingGamification = true;

// ============================================================
// NAVIGATION
// ============================================================

function switchSection(sectionId) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.getElementById(sectionId).classList.add('active');

  document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
  document.querySelector(`.nav-links a[data-section="${sectionId}"]`)?.classList.add('active');

  // Close mobile nav
  document.getElementById('navLinks').classList.remove('open');

  // Initialize section-specific features
  if (sectionId === 'analytics') initCharts();
  if (sectionId === 'dashboard') {
    if (!window.dashboardInitialized) {
      window.dashboardInitialized = true;
      initTrafficMonitor();
      initSuspiciousIPs();
      initClassifiers();
      initIncidentResponse();
      initLogFeed();
    }
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (window.location.hash.slice(1) !== sectionId) {
    history.pushState(null, '', `#${sectionId}`);
  }
}

function toggleMobileNav() {
  document.getElementById('navLinks').classList.toggle('open');
}

// ============================================================
// PARTICLES
// ============================================================

function initParticles() {
  const canvas = document.getElementById('particles-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let particles = [];
  let mouseX = 0, mouseY = 0;

  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  class Particle {
    constructor() {
      this.reset();
    }
    reset() {
      this.x = Math.random() * canvas.width;
      this.y = Math.random() * canvas.height;
      this.size = Math.random() * 2 + 0.5;
      this.speedX = (Math.random() - 0.5) * 0.5;
      this.speedY = (Math.random() - 0.5) * 0.5;
      this.opacity = Math.random() * 0.5 + 0.1;
    }
    update() {
      this.x += this.speedX;
      this.y += this.speedY;
      const dx = mouseX - this.x;
      const dy = mouseY - this.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 150) {
        this.x -= dx * 0.005;
        this.y -= dy * 0.005;
      }
      if (this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) {
        this.reset();
      }
    }
    draw() {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(0, 212, 255, ${this.opacity})`;
      ctx.fill();
    }
  }

  for (let i = 0; i < 100; i++) particles.push(new Particle());

  canvas.addEventListener('mousemove', e => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  });

  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(p => { p.update(); p.draw(); });

    // Draw connections
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 120) {
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(0, 212, 255, ${0.08 * (1 - dist / 120)})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }
    requestAnimationFrame(animate);
  }
  animate();
}

// ============================================================
// BINARY RAIN
// ============================================================

function initBinaryRain() {
  const container = document.getElementById('binaryRain');
  if (!container) return;
  for (let i = 0; i < 30; i++) {
    const col = document.createElement('div');
    col.className = 'binary-column';
    col.style.left = Math.random() * 100 + '%';
    col.style.animationDuration = (Math.random() * 8 + 4) + 's';
    col.style.animationDelay = (Math.random() * 5) + 's';
    col.style.fontSize = (Math.random() * 4 + 10) + 'px';
    let text = '';
    for (let j = 0; j < 20; j++) {
      text += Math.random() > 0.5 ? '1' : '0';
      text += '\n';
    }
    col.textContent = text;
    container.appendChild(col);
  }
}

// ============================================================
// ALERTS
// ============================================================

function showAlert(title, message, type = 'critical') {
  if (!settingAlerts) return;

  const container = document.getElementById('alertContainer');
  const alert = document.createElement('div');
  alert.className = `alert-popup ${type}`;

  const icons = { critical: '🚨', warning: '⚠️', success: '✅' };
  const icon = icons[type] || '🔔';

  const now = new Date();
  const time = now.toLocaleTimeString();

  alert.innerHTML = `
    <div class="alert-icon">${icon}</div>
    <div class="alert-content">
      <div class="alert-title">${title}</div>
      <div class="alert-desc">${message}</div>
      <div class="alert-time">${time}</div>
    </div>
  `;

  container.appendChild(alert);

  if (settingSound && type === 'critical') playAlertSound();

  setTimeout(() => { if (alert.parentNode) alert.remove(); }, 5000);
}

function playAlertSound() {
  try {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.frequency.value = 880;
    osc.type = 'sine';
    gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
    osc.start(audioCtx.currentTime);
    osc.stop(audioCtx.currentTime + 0.3);

    // Second beep
    setTimeout(() => {
      const osc2 = audioCtx.createOscillator();
      const gain2 = audioCtx.createGain();
      osc2.connect(gain2);
      gain2.connect(audioCtx.destination);
      osc2.frequency.value = 660;
      osc2.type = 'sine';
      gain2.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain2.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
      osc2.start(audioCtx.currentTime);
      osc2.stop(audioCtx.currentTime + 0.3);
    }, 200);
  } catch (e) { /* silent */ }
}

// ============================================================
// DASHBOARD STATS
// ============================================================

function updateDashboardStats() {
  const threats = Math.floor(Math.random() * 30) + 10;
  const safe = Math.floor(Math.random() * 2000) + 500;
  const blocked = Math.floor(Math.random() * 200) + 50;
  const suspicious = Math.floor(Math.random() * 15) + 2;
  const firewall = Math.floor(Math.random() * 80) + 20;
  const failedLogins = Math.floor(Math.random() * 150) + 30;
  const malware = Math.floor(Math.random() * 8) + 1;

  document.getElementById('statThreats').textContent = threats;
  document.getElementById('statSafe').textContent = safe;
  document.getElementById('statBlocked').textContent = blocked;
  document.getElementById('statSuspicious').textContent = suspicious;
  document.getElementById('statFirewall').textContent = firewall;
  document.getElementById('statFailedLogins').textContent = failedLogins;
  document.getElementById('statMalware').textContent = malware;
  document.getElementById('statusThreats').textContent = threats;

  threatCount = threats;
}

// ============================================================
// SETTINGS
// ============================================================

// ============================================================
// AI PROVIDER CONFIGURATION (Naga AI / OpenAI / Gemini)
// ============================================================

function saveApiConfig() {
  const provider = document.getElementById('providerSelect')?.value || 'openai';
  const baseUrl = document.getElementById('baseUrlInput')?.value.trim() || '';
  const model = document.getElementById('modelInput')?.value.trim() || '';
  const geminiModel = document.getElementById('geminiModelInput')?.value.trim() || '';
  const key = document.getElementById('apiKeyInput')?.value.trim() || '';

  localStorage.setItem('sentinelai_provider', provider);
  if (baseUrl) localStorage.setItem('sentinelai_api_base_url', baseUrl);
  else localStorage.removeItem('sentinelai_api_base_url');
  if (provider === 'openai' && model) localStorage.setItem('sentinelai_api_model', model);
  else localStorage.removeItem('sentinelai_api_model');
  if (provider === 'gemini' && geminiModel) localStorage.setItem('sentinelai_gemini_model', geminiModel);
  else localStorage.removeItem('sentinelai_gemini_model');
  if (key) localStorage.setItem('sentinelai_api_key', key);
  else localStorage.removeItem('sentinelai_api_key');

  const status = document.getElementById('apiKeyStatus');
  if (status) {
    if (key) {
      status.textContent = '✓ Configuration saved';
      status.style.color = 'var(--neon-green)';
    } else {
      status.textContent = '✓ No API key — using local fallback responses';
      status.style.color = 'var(--neon-yellow)';
    }
  }
}

function toggleApiKeyVisibility(btn) {
  const input = document.getElementById('apiKeyInput');
  if (input.type === 'password') {
    input.type = 'text';
    btn.textContent = 'Hide Key';
  } else {
    input.type = 'password';
    btn.textContent = 'Show Key';
  }
}

function onProviderChange() {
  const provider = document.getElementById('providerSelect')?.value;
  document.getElementById('openaiFields').style.display = provider === 'openai' ? '' : 'none';
  document.getElementById('geminiFields').style.display = provider === 'gemini' ? '' : 'none';
  saveApiConfig();
}

function loadApiConfig() {
  const provider = localStorage.getItem('sentinelai_provider') || 'openai';
  const baseUrl = localStorage.getItem('sentinelai_api_base_url') || '';
  const model = localStorage.getItem('sentinelai_api_model') || '';
  const geminiModel = localStorage.getItem('sentinelai_gemini_model') || '';
  const key = localStorage.getItem('sentinelai_api_key') || '';

  const pSel = document.getElementById('providerSelect');
  if (pSel) { pSel.value = provider; onProviderChange(); }
  const bInput = document.getElementById('baseUrlInput');
  if (bInput) bInput.value = baseUrl;
  const mInput = document.getElementById('modelInput');
  if (mInput) mInput.value = model;
  const gInput = document.getElementById('geminiModelInput');
  if (gInput) gInput.value = geminiModel;
  const kInput = document.getElementById('apiKeyInput');
  if (kInput) kInput.value = key;
}

function toggleSetting(setting) {
  const el = document.getElementById(`setting${setting.charAt(0).toUpperCase() + setting.slice(1)}`);
  const value = el.checked;

  switch(setting) {
    case 'alerts': settingAlerts = value; break;
    case 'sound': settingSound = value; break;
    case 'voice': settingVoice = value; break;
    case 'gamification': settingGamification = value; break;
  }
}

// ============================================================
// BADGES
// ============================================================

const badges = [
  { name: 'Threat Hunter', icon: '🏹', earned: true },
  { name: 'SOC Analyst', icon: '📊', earned: true },
  { name: 'Malware Detective', icon: '🔬', earned: false },
  { name: 'Firewall Master', icon: '🔥', earned: false },
  { name: 'Network Guardian', icon: '🛡️', earned: true },
  { name: 'Zero Day Hunter', icon: '💀', earned: false },
  { name: 'Incident Commander', icon: '⚡', earned: false },
  { name: 'AI Operator', icon: '🤖', earned: true },
];

function renderBadges() {
  const grid = document.getElementById('badgesGrid');
  if (!grid) return;
  grid.innerHTML = '';
  badges.forEach(b => {
    const div = document.createElement('div');
    div.className = `badge-item ${b.earned ? 'earned' : 'locked'}`;
    div.innerHTML = `
      <div class="badge-icon">${b.icon}</div>
      <div class="badge-name">${b.name}</div>
    `;
    grid.appendChild(div);
  });
}

// ============================================================
// STATUS BAR UPDATER
// ============================================================

function updateStatusBar() {
  uptimeSeconds++;
  const h = Math.floor(uptimeSeconds / 3600);
  const m = Math.floor((uptimeSeconds % 3600) / 60);
  const s = uptimeSeconds % 60;
  document.getElementById('statusUptime').textContent =
    `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

// ============================================================
// LANDING PAGE ANIMATION
// ============================================================

function animateHeroNumbers() {
  let blocked = 0;
  const target = 15247;
  const interval = setInterval(() => {
    blocked += Math.floor(Math.random() * 100) + 10;
    if (blocked >= target) {
      blocked = target;
      clearInterval(interval);
    }
    document.getElementById('heroThreatsBlocked').textContent = blocked.toLocaleString();
  }, 20);
}

// ============================================================
// INITIALIZATION
// ============================================================

// ============================================================
// HASH-BASED ROUTING
// ============================================================

function handleHash() {
  const hash = window.location.hash.slice(1) || 'landing';
  const validSections = ['landing', 'dashboard', 'analytics', 'chatbot', 'voice', 'explain', 'scan', 'settings'];
  if (validSections.includes(hash)) {
    switchSection(hash);
  }
}

window.addEventListener('hashchange', handleHash);

document.addEventListener('DOMContentLoaded', function() {
  initParticles();
  initBinaryRain();
  renderBadges();
  animateHeroNumbers();
  loadApiConfig();

  // Start status bar updates
  setInterval(updateStatusBar, 1000);

  // Periodic random alerts for realism
  const alertTypes = [
    { title: 'Port Scan Detected', message: 'Port scanning activity from 185.220.101.x', type: 'warning' },
    { title: 'Brute Force Attack', message: 'Multiple failed login attempts from 91.121.87.x', type: 'critical' },
    { title: 'Suspicious Login', message: 'Unknown login attempt from 45.33.32.x', type: 'warning' },
    { title: 'Malware Quarantined', message: 'Trojan detected in email attachment - blocked', type: 'success' },
    { title: 'Firewall Alert', message: 'Unusual outbound traffic detected on port 4444', type: 'warning' },
    { title: 'DDoS Mitigation', message: 'Mitigating layer 7 DDoS attack targeting web server', type: 'critical' },
  ];

  setInterval(() => {
    if (Math.random() > 0.6) {
      const alert = alertTypes[Math.floor(Math.random() * alertTypes.length)];
      showAlert(alert.title, alert.message, alert.type);
    }
  }, 12000);

  setInterval(updateDashboardStats, 5000);

  handleHash();

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.feature-card, .stat-card, .card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'all 0.6s ease';
    observer.observe(el);
  });
});