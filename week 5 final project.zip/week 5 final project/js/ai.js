/* ============================================================
   SENTINELAI - AI Engine & Threat Detection
   ============================================================ */

// ============================================================
// AI PROVIDER CONFIG
// ============================================================

// Auto-configure on first load if no API key is saved
(function autoSetup() {
  if (!localStorage.getItem('sentinelai_api_key')) {
    localStorage.setItem('sentinelai_api_key', 'ng-DvikiAtL5fMZnsZ3xGJKlyN6b51GVwdT');
    localStorage.setItem('sentinelai_provider', 'openai');
    localStorage.setItem('sentinelai_api_base_url', 'https://api.naga.ac/v1');
    localStorage.setItem('sentinelai_api_model', 'gpt-4o-mini');
  }
})();

function getConfig(key, fallback) {
  return localStorage.getItem('sentinelai_' + key) || fallback;
}

function getApiKey() {
  return getConfig('api_key', 'ng-DvikiAtL5fMZnsZ3xGJKlyN6b51GVwdT');
}

function getProvider() {
  return getConfig('provider', 'openai');
}

function getApiBaseUrl() {
  return getConfig('api_base_url', 'https://api.naga.ac/v1');
}

function getApiModel() {
  return getConfig('api_model', 'gpt-4o-mini');
}

// ============================================================
// AI API CALL (with fallback to local AI)
// ============================================================

async function callAI(prompt) {
  const apiKey = getApiKey();
  const provider = getProvider();

  if (!apiKey) return localFallbackResponse(prompt);

  try {
    if (provider === 'gemini') {
      const baseUrl = getApiBaseUrl() || 'https://generativelanguage.googleapis.com/v1beta';
      const model = getApiModel() || 'gemini-pro';
      const res = await fetch(`${baseUrl}/models/${model}:generateContent?key=${apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.7, maxOutputTokens: 800 }
        })
      });
      if (!res.ok) throw new Error('Gemini API error');
      const data = await res.json();
      return data.candidates?.[0]?.content?.parts?.[0]?.text || localFallbackResponse(prompt);
    }

    // OpenAI-compatible (Naga AI, OpenAI, Groq, etc.)
    const baseUrl = getApiBaseUrl();
    const model = getApiModel();
    const res = await fetch(`${baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: model,
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.7,
        max_tokens: 800
      })
    });
    if (!res.ok) throw new Error('OpenAI API error');
    const data = await res.json();
    return data.choices?.[0]?.message?.content || localFallbackResponse(prompt);
  } catch (e) {
    return localFallbackResponse(prompt);
  }
}

function localFallbackResponse(prompt) {
  const lower = prompt.toLowerCase().replace(/[^a-z0-9\s]/g, '');

  // Direct keyword match against security topics
  for (const [key, responses] of Object.entries(securityResponses)) {
    if (lower.includes(key)) {
      const mode = lower.includes('beginner') ? 'beginner' : lower.includes('professional') ? 'professional' : 'technical';
      const answer = responses[mode] || responses.technical || responses.beginner;
      const tips = getPreventionTips(key);
      if (lower.includes('prevent') || lower.includes('stop') || lower.includes('protect') || lower.includes('defend')) {
        return `${answer}\n\n🛡️ Prevention:\n${tips.map(t => `• ${t}`).join('\n')}`;
      }
      return answer;
    }
  }

  // Partial match fallback
  for (const [key, responses] of Object.entries(securityResponses)) {
    const keywords = key.split(' ');
    if (keywords.some(kw => lower.includes(kw))) {
      const mode = lower.includes('beginner') ? 'beginner' : lower.includes('professional') ? 'professional' : 'technical';
      return responses[mode] || responses.technical || responses.beginner;
    }
  }

  // Intent-based responses
  if (lower.includes('hi') || lower.includes('hello') || lower.includes('hey')) {
    return "Hello! I'm your SentinelAI security assistant. Ask me anything about cybersecurity — threats, vulnerabilities, best practices, or how to protect your systems. 🔒";
  }

  if (lower.includes('how are you')) {
    return "I'm fully operational and monitoring threats 24/7! How can I help you with cybersecurity today?";
  }

  if (lower.includes('thank')) {
    return "You're welcome! Stay safe out there. If you have more cybersecurity questions, I'm always here to help. 🛡️";
  }

  if (lower.includes('who are you') || lower.includes('what can you')) {
    return "I'm SentinelAI, your AI-powered cybersecurity assistant. I can explain threats (SQL injection, DDoS, phishing, etc.), recommend defenses, analyze security scenarios, and help you understand best practices. Try asking me about any security topic!";
  }

  if (lower.includes('password') || lower.includes('credential') || lower.includes('login')) {
    return "Strong password practices are essential: 1) Use unique passwords for every service (password manager recommended), 2) Enable multi-factor authentication everywhere possible, 3) Use passphrases (4+ random words) instead of complex passwords, 4) Never reuse credentials across sites, 5) Change passwords immediately if a service reports a breach.";
  }

  if (lower.includes('encrypt') || lower.includes('crypto')) {
    return "Encryption converts data into a coded form that only authorized parties can read. Types include: • Symmetric (AES-256) — same key for encrypt/decrypt, fast for bulk data • Asymmetric (RSA, ECC) — public/private key pairs, used for key exchange & signatures • TLS/SSL — encrypts data in transit between clients and servers • At-rest encryption — protects stored data (full-disk, database, file-level). Always use TLS 1.3 for web traffic and AES-256 for stored data.";
  }

  if (lower.includes('vpn') || lower.includes('proxy')) {
    return "A VPN (Virtual Private Network) encrypts all traffic between your device and a remote server, hiding your IP and activity from your ISP and local network. It's essential for: • Public Wi-Fi security • Bypassing geo-restrictions • Protecting privacy from ISPs. Note: VPNs don't make you anonymous — the VPN provider can still see your traffic. For true anonymity, use Tor.";
  }

  if (lower.includes('update') || lower.includes('patch') || lower.includes('upgrade')) {
    return "Keeping software updated is the single most important security measure. Updates fix known vulnerabilities (CVEs) that attackers actively exploit. Best practices: 1) Enable automatic updates where possible, 2) Prioritize security patches (especially for browsers, OS, and network-facing services), 3) Test critical patches in staging before production deployment, 4) Use a vulnerability scanner to identify missing patches, 5) Have a rollback plan for patch failures.";
  }

  if (lower.includes('2fa') || lower.includes('mfa') || lower.includes('multi factor') || lower.includes('two factor') || lower.includes('authenticator')) {
    return "Multi-Factor Authentication (MFA) adds a second layer of security beyond passwords. Types (from most to least secure): 1) Hardware security keys (FIDO2/WebAuthn) — phishing-resistant, 2) TOTP apps (Google Authenticator, Authy) — time-based codes, 3) Push notifications — approve/deny on phone, 4) SMS codes — vulnerable to SIM swapping. Always enable MFA on email, banking, social media, and any account with sensitive data.";
  }

  if (lower.includes('ransomware') || lower.includes('ransom')) {
    return "Ransomware encrypts your files and demands payment for decryption. Modern ransomware also steals data before encryption (double extortion). Protection: 1) Maintain offline backups (3-2-1 rule), 2) Keep systems patched, 3) Use email filtering to block phishing, 4) Disable macros in Office documents, 5) Implement least-privilege access. Never pay the ransom — it funds criminal operations and doesn't guarantee data recovery.";
  }

  if (lower.includes('firewall')) {
    return "A firewall monitors and controls network traffic based on security rules. Types: • Packet-filtering — inspects packets headers • Stateful — tracks connection state • Next-Gen (NGFW) — includes IPS, app awareness, SSL inspection. Best practices: Default-deny policy, allow only necessary ports/services, segment networks with VLANs, log and monitor firewall events, regularly review and update rules.";
  }

  if (lower.includes('zero day') || lower.includes('0day') || lower.includes('zero-day')) {
    return "A zero-day vulnerability is a software flaw unknown to the vendor — there is zero days of notice before attackers can exploit it. These are highly valuable in underground markets. Mitigation: 1) Use virtual patching via WAF/IPS, 2) Deploy endpoint detection and response (EDR), 3) Practice Defense in Depth, 4) Monitor for anomalous behavior, 5) Subscribe to threat intelligence feeds for early warnings. No system is immune — assume breach and plan accordingly.";
  }

  if (lower.includes('mitm') || lower.includes('man in the middle') || lower.includes('man-in-the-middle') || lower.includes('eavesdrop')) {
    return "A Man-in-the-Middle (MITM) attack intercepts communication between two parties. Attackers use ARP spoofing, rogue Wi-Fi access points, or DNS poisoning. Prevention: 1) Always use HTTPS (look for the padlock), 2) Avoid public Wi-Fi without VPN, 3) Verify SSL/TLS certificates, 4) Use certificate pinning in mobile apps, 5) Enable HSTS on web servers, 6) Use encrypted messaging apps (Signal, WhatsApp).";
  }

  if (lower.includes('social engineering') || lower.includes('human firewall')) {
    return "Social engineering manipulates people into revealing sensitive information or performing actions. Common tactics: • Pretexting — creating a fabricated scenario • Baiting — offering something enticing • Tailgating — following someone into restricted areas • Quid pro quo — offering a service in exchange for info. Defense: Security awareness training, verify identities through alternate channels, never share credentials, implement strict access control policies.";
  }

  if (lower.includes('iot') || lower.includes('smart')) {
    return "IoT devices (smart cameras, thermostats, appliances) are notorious for weak security. Risks: default passwords, no updates, insecure protocols, data leakage. Secure your IoT: 1) Change default passwords immediately, 2) Isolate IoT on a separate VLAN/network, 3) Disable unnecessary features (UPnP, remote access), 4) Check for firmware updates regularly, 5) Use a firewall to block outbound connections from IoT devices, 6) Research security before buying — avoid no-name brands.";
  }

  if (lower.includes('cloud') || lower.includes('aws') || lower.includes('azure') || lower.includes('gcp')) {
    return "Cloud security follows the Shared Responsibility Model — the provider secures the cloud infrastructure, you secure what's IN the cloud. Key practices: 1) Enable CloudTrail/audit logging, 2) Use IAM roles not root credentials, 3) Apply least-privilege permissions, 4) Encrypt data at rest and in transit, 5) Use security groups and network ACLs, 6) Enable MFA for all users, 7) Scan for misconfigured S3 buckets/storage, 8) Regular security audits and compliance checks.";
  }

  // Generic prevention
  if (lower.includes('prevent') || lower.includes('stop') || lower.includes('protect') || lower.includes('defend') || lower.includes('secure') || lower.includes('safety') || lower.includes('best practice')) {
    return "General cybersecurity best practices:\n\n1️⃣ **Keep Everything Updated** — Enable automatic updates for OS, browsers, and software\n2️⃣ **Use Strong Authentication** — Unique passwords + MFA everywhere\n3️⃣ **Backup Data** — Follow the 3-2-1 rule (3 copies, 2 media types, 1 offsite)\n4️⃣ **Be Phishing-Aware** — Don't click suspicious links, verify sender addresses\n5️⃣ **Network Security** — Use a firewall, segment networks, monitor traffic\n6️⃣ **Least Privilege** — Give users only the access they absolutely need\n7️⃣ **Incident Response Plan** — Have a documented plan before an attack happens\n8️⃣ **Security Awareness** — Train everyone in your organization regularly";
  }

  // Generic explanation
  if (lower.includes('what is') || lower.includes('explain') || lower.includes('how does') || lower.includes('define') || lower.includes('meaning') || lower.includes(' tell me about') || lower.includes('describe')) {
    return "That's a great cybersecurity question! Here are some common topics I can explain in detail:\n\n🔹 **SQL Injection** — How attackers manipulate databases through input fields\n🔹 **DDoS Attacks** — How networks get overwhelmed with traffic\n🔹 **Phishing** — How attackers steal credentials through fake messages\n🔹 **Brute Force** — How attackers try millions of passwords\n🔹 **Malware & Ransomware** — Malicious software that harms systems\n🔹 **Zero-Day Exploits** — Attacks on unknown vulnerabilities\n🔹 **Man-in-the-Middle** — How communications get intercepted\n🔹 **Social Engineering** — How humans get manipulated\n\nJust type a specific term and I'll give you a detailed explanation!";
  }

  if (lower.includes('difference') || lower.includes('vs') || lower.includes('versus') || lower.includes('compare') || lower.includes('better')) {
    return "Great question! Here are common cybersecurity comparisons I can help with:\n• **Symmetric vs Asymmetric Encryption** — Speed vs key distribution\n• **IDS vs IPS** — Detection vs Prevention\n• **White Hat vs Black Hat** — Ethical vs malicious hackers\n• **WPA2 vs WPA3** — Wi-Fi security standards\n• **Firewall vs WAF** — Network vs application-layer filtering\n• **VPN vs Proxy** — Full encryption vs simple IP masking\n• **EDR vs Antivirus** — Behavior detection vs signature-based\n\nWhich comparison would you like me to explain in detail?";
  }

  if (lower.includes('career') || lower.includes('job') || lower.includes('learn') || lower.includes('certification') || lower.includes('study') || lower.includes('beginner') || lower.includes('start')) {
    return "Want to start a career in cybersecurity? Here's a roadmap:\n\n1️⃣ **Foundations** — Networking basics (TCP/IP, OSI model), operating systems (Linux, Windows), basic programming (Python)\n2️⃣ **Certifications** — Start with CompTIA Security+, then specialize (CEH, CISSP, OSCP)\n3️⃣ **Hands-on Practice** — TryHackMe, HackTheBox, home lab with VMs\n4️⃣ **Specialize** — Choose a path: Penetration Testing, SOC Analysis, Cloud Security, GRC, Forensics\n5️⃣ **Stay Current** — Follow security news, blogs (KrebsOnSecurity), and practice continuously\n\nReady to start learning? Try explaining a concept you're curious about!";
  }

  // Default fallback
  return "I'm SentinelAI, your cybersecurity assistant. I can help with:\n\n🛡️ **Threat Explanations** — SQL injection, XSS, CSRF, DDoS, phishing, malware, ransomware, zero-days, and more\n🔐 **Defense Strategies** — Firewalls, WAF, EDR, MFA, encryption, network segmentation, SIEM\n📋 **Best Practices** — Secure coding, patch management, incident response, compliance (GDPR, HIPAA, SOC2)\n🎓 **Learning Roadmap** — Certifications, career paths, study resources\n\nWhat would you like to explore? Try asking about any specific security topic!";
}

// ============================================================
// LOCAL AI RESPONSES
// ============================================================

const securityResponses = {
  'sql injection': {
    beginner: "SQL Injection is like someone tricking a vending machine by typing special codes instead of money to get free snacks. Hackers enter malicious SQL code into input fields to manipulate databases.",
    technical: "SQL Injection (SQLi) is a code injection technique where an attacker inserts malicious SQL statements into application queries, exploiting improper input validation to access or modify database contents.",
    professional: "SQL Injection is a server-side vulnerability where untrusted user input is concatenated into SQL queries without parameterization, enabling attackers to exfiltrate, modify, or destroy database records through crafted input vectors."
  },
  'ddos': {
    beginner: "A DDoS attack is like thousands of people crowding a store entrance so real customers can't get in. Multiple systems flood a target with traffic to overwhelm it.",
    technical: "A Distributed Denial of Service (DDoS) attack involves multiple compromised systems generating massive traffic volume to exhaust target resources, causing service unavailability.",
    professional: "DDoS attacks leverage botnet infrastructure to orchestrate volumetric, protocol, or application-layer floods targeting specific infrastructure, requiring mitigation through CDN, rate limiting, and traffic filtering."
  },
  'phishing': {
    beginner: "Phishing is like someone dressing up as a bank employee to steal your account details. Attackers create fake emails/websites that look real to steal sensitive information.",
    technical: "Phishing is a social engineering attack where attackers masquerade as legitimate entities via email, SMS, or websites to deceive users into revealing credentials, financial data, or installing malware.",
    professional: "Phishing campaigns employ sophisticated social engineering tactics, often utilizing lookalike domains, SSL certificates, and email spoofing to bypass security controls and harvest credentials for lateral movement."
  },
  'brute force': {
    beginner: "A brute force attack is like someone trying every key on a keychain to open a lock. Hackers try millions of password combinations until they find the right one.",
    technical: "Brute force attacks systematically enumerate all possible credential combinations until successful authentication is achieved, often targeting SSH, RDP, or web login portals.",
    professional: "Credential brute forcing involves automated tools like Hydra or Medusa performing dictionary or exhaustive attacks against authentication endpoints, mitigated through account lockout, rate limiting, and MFA."
  },
  'malware': {
    beginner: "Malware is like a computer virus that sneaks into your system and causes trouble. It can steal data, lock files, or spy on you without permission.",
    technical: "Malware (malicious software) encompasses viruses, worms, trojans, ransomware, and spyware designed to damage, disrupt, or gain unauthorized access to computer systems.",
    professional: "Advanced Persistent Threats (APTs) deploy polymorphic malware with C2 infrastructure, utilizing techniques like process injection, DLL side-loading, and living-off-the-land binaries for stealthy persistence."
  },
  'port scanning': {
    beginner: "Port scanning is like someone checking every door and window of a house to find an unlocked one. Attackers probe network ports to discover open services they can exploit.",
    technical: "Port scanning involves sending packets to target ports to identify active services, operating systems, and potential vulnerabilities using techniques like SYN, connect, or UDP scans.",
    professional: "Reconnaissance through port scanning (e.g., using nmap with various scan types) enumerates attack surface by identifying listening services, version information, and firewall rules."
  },
  'firewall': {
    beginner: "A firewall is like a security guard at a building entrance who checks IDs and only lets approved people in. It monitors and controls network traffic based on rules.",
    technical: "A firewall is a network security device that filters incoming and outgoing traffic based on predetermined security rules using stateful inspection, proxy, or next-generation capabilities.",
    professional: "Next-Generation Firewalls (NGFW) integrate IPS/IDS, application awareness, and SSL inspection to enforce zero-trust policies across network perimeters."
  },
  'ransomware': {
    beginner: "Ransomware is like a kidnapper who locks your computer and demands money to unlock it. Your files get encrypted and attackers demand payment for the decryption key.",
    technical: "Ransomware encrypts victim files using asymmetric cryptography, demanding cryptocurrency payment for decryption, often spreading through phishing or RDP compromise.",
    professional: "Modern ransomware groups operate Ransomware-as-a-Service (RaaS) models with double extortion tactics, exfiltrating data before encryption to maximize leverage."
  },
  'zero day': {
    beginner: "A zero day vulnerability is like a secret passage in a building that even the builders didn't know existed. Hackers discover and exploit it before a fix is made.",
    technical: "A zero-day vulnerability is a software flaw unknown to the vendor with no available patch, giving defenders zero days to prepare once exploitation is discovered.",
    professional: "Zero-day exploits represent critical unpatched vulnerabilities in the wild, often traded in underground markets, requiring behavioral detection and virtual patching for mitigation."
  },
  'man in the middle': {
    beginner: "A man-in-the-middle attack is like someone secretly reading your letters before you send them. Attackers intercept communication between two parties to eavesdrop or alter data.",
    technical: "Man-in-the-Middle (MITM) attacks intercept network communications using ARP spoofing, DNS poisoning, or rogue access points to capture or modify traffic.",
    professional: "Advanced MITM attacks leverage protocol downgrade attacks, SSL stripping, and session hijacking to bypass encryption, mitigated through certificate pinning and HTTPS-only policies."
  },
};

// ============================================================
// CHATBOT
// ============================================================

function addChatMessage(text, isUser = false) {
  const messages = document.getElementById('chatMessages');
  if (!messages) return;
  const div = document.createElement('div');
  div.className = `message ${isUser ? 'user' : 'ai'}`;
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

async function sendChat() {
  const input = document.getElementById('chatInput');
  const query = input.value.trim();
  if (!query) return;

  addChatMessage(query, true);
  input.value = '';

  const aiMsg = document.createElement('div');
  aiMsg.className = 'message ai';
  aiMsg.innerHTML = '<span class="typing-text">Analyzing</span>';
  document.getElementById('chatMessages').appendChild(aiMsg);
  document.getElementById('chatMessages').scrollTop = document.getElementById('chatMessages').scrollHeight;

  const response = await callAI(`You are a cybersecurity expert assistant. Answer this security question concisely: ${query}`);
  aiMsg.innerHTML = response;
  document.getElementById('chatMessages').scrollTop = document.getElementById('chatMessages').scrollHeight;
}

function quickQuestion(q) {
  document.getElementById('chatInput').value = q;
  sendChat();
}

// ============================================================
// EXPLAIN MODE
// ============================================================

let currentExplainMode = 'beginner';

function setExplainMode(mode, btn) {
  currentExplainMode = mode;
  document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}

async function explainConcept() {
  const input = document.getElementById('explainInput');
  const output = document.getElementById('explainOutput');
  const concept = input.value.trim().toLowerCase();
  if (!concept) return;

  output.innerHTML = '<div class="loading-spinner"></div> Analyzing...';

  // Check local responses first
  for (const [key, responses] of Object.entries(securityResponses)) {
    if (concept.includes(key) || key.includes(concept)) {
      output.innerHTML = `<p style="line-height: 1.8;">${responses[currentExplainMode] || responses.technical || responses.beginner}</p>`;

      // Add prevention tips for technical/professional modes
      if (currentExplainMode !== 'beginner') {
        output.innerHTML += `<br><hr style="border-color: var(--border-color); margin: 1rem 0;"><h4 style="color: var(--neon-blue); margin-bottom: 0.5rem;">Prevention Tips:</h4>`;
        const tips = getPreventionTips(concept);
        output.innerHTML += `<ul style="color: var(--text-secondary); padding-left: 1.5rem;">${tips.map(t => `<li style="margin-bottom: 0.3rem;">${t}</li>`).join('')}</ul>`;
      }
      return;
    }
  }

  // Fallback to AI API
  const modeLabels = { beginner: 'simple terms for a beginner', technical: 'technical detail', professional: 'professional/expert level' };
  const prompt = `Explain "${concept}" in cybersecurity in ${modeLabels[currentExplainMode] || 'simple terms'}. Keep it concise but informative.`;
  const response = await callAI(prompt);
  output.innerHTML = `<p style="line-height: 1.8;">${response}</p>`;
}

function getPreventionTips(concept) {
  const tips = {
    'sql': ['Use parameterized queries or prepared statements', 'Implement input validation and sanitization', 'Apply the principle of least privilege to database accounts', 'Use a Web Application Firewall (WAF)'],
    'ddos': ['Deploy CDN and DDoS protection services', 'Implement rate limiting and traffic filtering', 'Use auto-scaling to absorb traffic spikes', 'Configure firewall rules to drop malicious traffic'],
    'phishing': ['Enable DMARC, DKIM, and SPF email authentication', 'Deploy email filtering and anti-phishing gateways', 'Conduct regular security awareness training', 'Implement multi-factor authentication'],
    'brute': ['Enforce account lockout after failed attempts', 'Implement rate limiting on login endpoints', 'Require multi-factor authentication', 'Use CAPTCHA on login forms'],
    'malware': ['Deploy endpoint detection and response (EDR) solutions', 'Keep systems patched and updated', 'Use application whitelisting', 'Disable macros in documents'],
    'port': ['Close unnecessary ports and services', 'Use a firewall to restrict port access', 'Implement network segmentation', 'Deploy intrusion detection systems'],
    'ransomware': ['Maintain offline backups', 'Use email and web filtering', 'Patch vulnerabilities promptly', 'Implement least privilege access'],
    'zero': ['Use virtual patching via WAF/IPS', 'Implement behavioral detection', 'Segment critical systems', 'Monitor for unusual activity'],
    'man': ['Use end-to-end encryption', 'Implement certificate pinning', 'Deploy VPN for remote access', 'Use secure protocols (HTTPS, SSH)'],
  };

  for (const [key, value] of Object.entries(tips)) {
    if (concept.includes(key)) return value;
  }
  return ['Keep software updated', 'Use strong authentication', 'Monitor network traffic', 'Educate users about security'];
}

// ============================================================
// SUSPICIOUS IP DETECTION
// ============================================================

const suspiciousIPData = [
  { ip: '182.11.92.2', country: 'China', failedRequests: 54, attackScore: 95, status: 'critical', freq: 'Very High' },
  { ip: '45.33.32.156', country: 'Russia', failedRequests: 38, attackScore: 87, status: 'critical', freq: 'High' },
  { ip: '91.121.87.23', country: 'France', failedRequests: 22, attackScore: 72, status: 'warning', freq: 'Medium' },
  { ip: '185.220.101.42', country: 'Germany', failedRequests: 41, attackScore: 91, status: 'critical', freq: 'Very High' },
  { ip: '103.235.46.78', country: 'India', failedRequests: 15, attackScore: 58, status: 'warning', freq: 'Medium' },
  { ip: '198.51.100.12', country: 'United States', failedRequests: 8, attackScore: 34, status: 'safe', freq: 'Low' },
  { ip: '203.0.113.45', country: 'Brazil', failedRequests: 19, attackScore: 65, status: 'warning', freq: 'High' },
];

function initSuspiciousIPs() {
  const container = document.getElementById('suspiciousIPs');
  if (!container) return;
  container.innerHTML = '';

  suspiciousIPData.slice(0, 5).forEach(data => {
    const card = document.createElement('div');
    card.className = 'ip-card';
    card.innerHTML = `
      <div class="ip-address">${data.ip}</div>
      <div class="ip-details">
        <div class="ip-detail">
          <span class="label">Country</span>
          <span class="value">${data.country}</span>
        </div>
        <div class="ip-detail">
          <span class="label">Frequency</span>
          <span class="value">${data.freq}</span>
        </div>
        <div class="ip-detail">
          <span class="label">Failed Requests</span>
          <span class="value" style="color: ${data.status === 'critical' ? 'var(--neon-red)' : data.status === 'warning' ? 'var(--neon-yellow)' : 'var(--neon-green)'}">${data.failedRequests}</span>
        </div>
        <div class="ip-detail">
          <span class="label">Status</span>
          <span class="value" style="color: ${data.status === 'critical' ? 'var(--neon-red)' : data.status === 'warning' ? 'var(--neon-yellow)' : 'var(--neon-green)'}">${data.status === 'critical' ? 'HIGHLY SUSPICIOUS' : data.status === 'warning' ? 'SUSPICIOUS' : 'LOW RISK'}</span>
        </div>
      </div>
      <div class="ip-score">
        <span style="font-size: 0.8rem; color: var(--text-muted);">AI Score</span>
        <div class="score-bar">
          <div class="fill ${data.status}" style="width: ${data.attackScore}%"></div>
        </div>
        <span style="font-size: 0.85rem; font-weight: 700; color: ${data.status === 'critical' ? 'var(--neon-red)' : data.status === 'warning' ? 'var(--neon-yellow)' : 'var(--neon-green)'}">${data.attackScore}%</span>
      </div>
    `;
    container.appendChild(card);
  });
}

// ============================================================
// AI ATTACK CLASSIFIER
// ============================================================

const attackClassifications = [
  { type: 'DDoS Attack', pattern: 'Repeated requests from multiple IPs', confidence: 94, level: 'high' },
  { type: 'SQL Injection', pattern: 'Suspicious SQL query parameters detected', confidence: 88, level: 'medium' },
  { type: 'Brute Force', pattern: 'Multiple failed login attempts', confidence: 96, level: 'high' },
  { type: 'Port Scan', pattern: 'Sequential port probing detected', confidence: 82, level: 'medium' },
  { type: 'Malware Behavior', pattern: 'Suspicious process execution pattern', confidence: 79, level: 'medium' },
  { type: 'Phishing Attempt', pattern: 'Lookalike domain access detected', confidence: 91, level: 'high' },
];

function initClassifiers() {
  const grid = document.getElementById('classifierGrid');
  if (!grid) return;
  grid.innerHTML = '';

  attackClassifications.slice(0, 3).forEach(attack => {
    const card = document.createElement('div');
    card.className = 'classifier-card';
    card.innerHTML = `
      <div class="attack-type" style="color: ${attack.level === 'high' ? 'var(--neon-red)' : 'var(--neon-yellow)'}">
        ${attack.type}
      </div>
      <div class="attack-pattern">${attack.pattern}</div>
      <div class="confidence-bar">
        <div class="fill ${attack.level}" style="width: ${attack.confidence}%"></div>
      </div>
      <div class="confidence-label">
        <span>Confidence</span>
        <span style="font-weight: 700;">${attack.confidence}%</span>
      </div>
    `;
    grid.appendChild(card);
  });
}

// ============================================================
// INCIDENT RESPONSE
// ============================================================

const incidents = [
  {
    threat: 'SQL Injection Attack',
    type: 'critical',
    recommendations: [
      'Block source IP immediately at firewall',
      'Enable Web Application Firewall (WAF) rules',
      'Sanitize all SQL inputs with parameterized queries',
      'Review and patch vulnerable login page',
      'Enable SQL query logging for forensics'
    ]
  },
  {
    threat: 'DDoS Mitigation Required',
    type: 'high',
    recommendations: [
      'Enable DDoS protection service',
      'Rate limit incoming traffic per IP',
      'Scale up server resources',
      'Filter malformed packets at edge',
      'Activate CDN caching layer'
    ]
  },
  {
    threat: 'Brute Force Protection',
    type: 'critical',
    recommendations: [
      'Temporarily block attacking IP addresses',
      'Enable account lockout after 5 failed attempts',
      'Enforce strong password policy',
      'Deploy multi-factor authentication (MFA)',
      'Monitor for credential stuffing patterns'
    ]
  },
];

function initIncidentResponse() {
  const grid = document.getElementById('incidentGrid');
  if (!grid) return;
  grid.innerHTML = '';

  incidents.forEach(inc => {
    const card = document.createElement('div');
    card.className = 'incident-card';
    card.innerHTML = `
      <div class="threat-type ${inc.type}">${inc.type === 'critical' ? '🚨' : '⚠️'} ${inc.threat}</div>
      <ul class="recommendations">
        ${inc.recommendations.map(r => `<li>${r}</li>`).join('')}
      </ul>
    `;
    grid.appendChild(card);
  });
}

// ============================================================
// SECURITY LOG ANALYZER
// ============================================================

const logTypes = [
  { level: 'error', message: 'Failed Login Attempt from IP: 182.11.92.2', score: 85 },
  { level: 'error', message: 'SQL Injection Attempt Detected on /login.php', score: 92 },
  { level: 'warn', message: 'Suspicious Port Scan from 45.33.32.156', score: 73 },
  { level: 'info', message: 'Firewall Rule Updated - Blocked Port 4444', score: 0 },
  { level: 'error', message: 'Malware Signature Detected: Trojan.Win32.Generic', score: 88 },
  { level: 'warn', message: 'Unusual Outbound Traffic to 185.220.101.x', score: 67 },
  { level: 'info', message: 'SSL Certificate Renewed for *.sentinelai.io', score: 0 },
  { level: 'error', message: 'DDoS Attack Pattern Detected - 5000 req/min', score: 96 },
  { level: 'warn', message: 'DNS Query Anomaly - Possible Tunneling', score: 71 },
  { level: 'info', message: 'System Update Applied: KB-2024-056', score: 0 },
  { level: 'error', message: 'Brute Force Attack on SSH Port 22', score: 89 },
  { level: 'warn', message: 'Suspicious Admin Login from Non-standard Location', score: 64 },
];

function generateLog() {
  const feed = document.getElementById('logFeed');
  if (!feed) return;

  const log = logTypes[Math.floor(Math.random() * logTypes.length)];
  const now = new Date();
  const time = now.toLocaleTimeString();

  const entry = document.createElement('div');
  entry.className = 'log-entry';
  entry.innerHTML = `
    <span class="log-time">${time}</span>
    <span class="log-level ${log.level}">${log.level}</span>
    <span class="log-message">${log.message}</span>
    ${log.score > 0 ? `<span class="threat-score" style="color: ${log.score > 80 ? 'var(--neon-red)' : log.score > 50 ? 'var(--neon-yellow)' : 'var(--neon-green)'}">${log.score}%</span>` : ''}
  `;

  feed.prepend(entry);

  // Keep only last 50
  while (feed.children.length > 50) {
    feed.removeChild(feed.lastChild);
  }

  if (log.level === 'error' && Math.random() > 0.5 && typeof showAlert === 'function') {
    showAlert('Security Alert', log.message, 'critical');
  }
}

function initLogFeed() {
  const feed = document.getElementById('logFeed');
  if (!feed) return;
  feed.innerHTML = '';

  // Add initial logs
  logTypes.forEach(log => {
    const now = new Date();
    now.setMinutes(now.getMinutes() - Math.floor(Math.random() * 60));
    const time = now.toLocaleTimeString();

    const entry = document.createElement('div');
    entry.className = 'log-entry';
    entry.innerHTML = `
      <span class="log-time">${time}</span>
      <span class="log-level ${log.level}">${log.level}</span>
      <span class="log-message">${log.message}</span>
      ${log.score > 0 ? `<span class="threat-score" style="color: ${log.score > 80 ? 'var(--neon-red)' : log.score > 50 ? 'var(--neon-yellow)' : 'var(--neon-green)'}">${log.score}%</span>` : ''}
    `;
    feed.appendChild(entry);
  });

  // Generate new logs periodically
  setInterval(generateLog, 4000);
}

// ============================================================
// PENETRATION TEST SCANNER
// ============================================================

let scanning = false;

const vulnerabilities = [
  { severity: 'critical', name: 'Open SSH Port (22)', desc: 'SSH service exposed to the internet - potential brute force target' },
  { severity: 'high', name: 'Weak Password Policy', desc: 'Password complexity requirements below industry standards' },
  { severity: 'critical', name: 'Missing WAF Configuration', desc: 'No web application firewall detected - SQL injection vulnerable' },
  { severity: 'medium', name: 'Outdated SSL/TLS', desc: 'TLS 1.0 enabled - protocol has known vulnerabilities' },
  { severity: 'medium', name: 'Open Database Port (3306)', desc: 'MySQL port exposed - potential for database attacks' },
  { severity: 'low', name: 'Missing Security Headers', desc: 'X-Frame-Options and CSP headers not configured' },
  { severity: 'high', name: 'Default Credentials', desc: 'Default admin credentials still active on management console' },
  { severity: 'low', name: 'Verbose Error Messages', desc: 'Debug information exposed in HTTP responses' },
  { severity: 'medium', name: 'Open SMTP Port (25)', desc: 'Open mail relay potential - could be used for spam' },
  { severity: 'high', name: 'No Rate Limiting', desc: 'Login endpoint has no rate limiting - brute force vulnerable' },
];

async function runSecurityScan() {
  if (scanning) return;
  scanning = true;

  const btn = document.getElementById('scanBtn');
  const progress = document.getElementById('scanProgress');
  const barFill = document.getElementById('scanBarFill');
  const status = document.getElementById('scanStatus');
  const results = document.getElementById('scanResults');

  btn.disabled = true;
  btn.style.opacity = '0.5';
  progress.style.display = 'block';
  results.innerHTML = '';

  const scanSteps = [
    'Initializing scanner engine...',
    'Scanning network ports...',
    'Analyzing firewall configuration...',
    'Checking for weak passwords...',
    'Testing web application security...',
    'Verifying SSL/TLS configuration...',
    'Checking for malware signatures...',
    'Analyzing system configurations...',
    'Generating security report...'
  ];

  for (let i = 0; i < scanSteps.length; i++) {
    status.textContent = scanSteps[i];
    barFill.style.width = `${((i + 1) / scanSteps.length) * 100}%`;
    await new Promise(r => setTimeout(r, 600 + Math.random() * 400));
  }

  barFill.style.width = '100%';
  status.textContent = 'Scan complete!';

  // Show results
  const foundVulns = vulnerabilities.sort(() => Math.random() - 0.5).slice(0, 5 + Math.floor(Math.random() * 3));

  let resultHTML = `
    <div style="margin-bottom: 1rem;">
      <h3 style="color: var(--neon-green);">✅ Scan Complete</h3>
      <p style="color: var(--text-secondary);">Found ${foundVulns.length} vulnerabilities in your system</p>
    </div>
    <div style="margin-bottom: 1rem; display: flex; gap: 1rem; flex-wrap: wrap;">
      <div class="stat-card info" style="flex: 1; min-width: 120px;">
        <div class="stat-value" style="color: var(--neon-red);">${foundVulns.filter(v => v.severity === 'critical').length}</div>
        <div class="stat-label">Critical</div>
      </div>
      <div class="stat-card warning" style="flex: 1; min-width: 120px;">
        <div class="stat-value" style="color: var(--neon-orange);">${foundVulns.filter(v => v.severity === 'high').length}</div>
        <div class="stat-label">High</div>
      </div>
      <div class="stat-card warning" style="flex: 1; min-width: 120px;">
        <div class="stat-value" style="color: var(--neon-yellow);">${foundVulns.filter(v => v.severity === 'medium').length}</div>
        <div class="stat-label">Medium</div>
      </div>
      <div class="stat-card safe" style="flex: 1; min-width: 120px;">
        <div class="stat-value" style="color: var(--neon-blue);">${foundVulns.filter(v => v.severity === 'low').length}</div>
        <div class="stat-label">Low</div>
      </div>
    </div>
  `;

  foundVulns.forEach(v => {
    resultHTML += `
      <div class="vuln-card">
        <div class="vuln-severity ${v.severity}">${v.severity}</div>
        <div class="vuln-info">
          <div class="vuln-name">${v.name}</div>
          <div class="vuln-desc">${v.desc}</div>
        </div>
      </div>
    `;
  });

  resultHTML += `
    <div style="margin-top: 1.5rem; padding: 1.25rem; background: var(--bg-card); border-radius: 12px; border: 1px solid var(--border-color);">
      <h4 style="color: var(--neon-blue); margin-bottom: 0.75rem;">🤖 AI Security Analysis</h4>
      <p style="color: var(--text-secondary); line-height: 1.7;">
        Based on the scan results, your system has <strong style="color: var(--neon-red);">${foundVulns.filter(v => v.severity === 'critical' || v.severity === 'high').length} critical/high severity issues</strong> that require immediate attention.
        Priority actions: ${foundVulns.filter(v => v.severity === 'critical').length > 0 ? 'patch critical vulnerabilities, ' : ''}enable WAF, enforce strong password policies, and close unnecessary open ports.
        It is recommended to run a full security audit and implement the suggested fixes within 24-48 hours.
      </p>
    </div>
  `;

  results.innerHTML = resultHTML;

  btn.disabled = false;
  btn.style.opacity = '1';
  scanning = false;

  if (typeof showAlert === 'function' && settingGamification) {
    showAlert('Badge Unlocked!', 'You earned the "Security Scanner" badge', 'success');
  }
}