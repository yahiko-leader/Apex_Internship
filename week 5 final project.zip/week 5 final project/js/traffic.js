/* ============================================================
   SENTINELAI - Network Traffic Monitor
   ============================================================ */

const protocols = ['TCP', 'UDP', 'ICMP', 'HTTP', 'HTTPS', 'DNS', 'SSH', 'FTP', 'SMTP'];
const ports = [22, 80, 443, 8080, 8443, 53, 25, 110, 143, 3306, 5432, 27017, 6379, 3389];
const statuses = ['allowed', 'blocked', 'suspicious'];
const sizes = ['64B', '128B', '256B', '512B', '1KB', '2KB', '4KB', '8KB', '16KB', '32KB', '64KB'];
const srcIPs = [
  '192.168.1.5', '10.0.0.12', '172.16.0.8', '10.0.1.45', '192.168.0.102',
  '10.0.0.200', '172.16.1.33', '192.168.2.15', '10.0.2.88', '172.16.0.254'
];
const dstIPs = [
  '45.33.32.156', '185.220.101.42', '91.121.87.23', '104.28.7.89', '198.51.100.12',
  '203.0.113.45', '23.235.33.178', '52.85.144.201', '34.194.128.45', '151.101.1.140'
];

let trafficEntries = 0;

function generateTrafficPacket() {
  const src = srcIPs[Math.floor(Math.random() * srcIPs.length)];
  const dst = dstIPs[Math.floor(Math.random() * dstIPs.length)];
  const protocol = protocols[Math.floor(Math.random() * protocols.length)];
  const port = ports[Math.floor(Math.random() * ports.length)];
  const status = (() => {
    const r = Math.random();
    if (r < 0.6) return 'allowed';
    if (r < 0.85) return 'blocked';
    return 'suspicious';
  })();
  const size = sizes[Math.floor(Math.random() * sizes.length)];

  return { src, dst, protocol, port, status, size };
}

function addTrafficRow(packet) {
  const feed = document.getElementById('trafficFeed');
  if (!feed) return;

  const row = document.createElement('div');
  row.className = 'traffic-row';
  row.innerHTML = `
    <span class="src">${packet.src}</span>
    <span class="dst">${packet.dst}</span>
    <span class="protocol">${packet.protocol}</span>
    <span class="port">${packet.port}</span>
    <span class="status ${packet.status}">${packet.status}</span>
    <span style="color: var(--text-muted);">${packet.size}</span>
  `;

  feed.appendChild(row);
  trafficEntries++;
  document.getElementById('statusPackets').textContent = trafficEntries;

  // Keep only last 50 entries for performance
  while (feed.children.length > 50) {
    feed.removeChild(feed.firstChild);
  }

  // Scroll to bottom
  const container = document.getElementById('trafficContainer');
  if (container) container.scrollTop = container.scrollHeight;

  // Randomly trigger alerts based on suspicious traffic
  if (packet.status === 'suspicious' && Math.random() > 0.7) {
    const threats = [
      { title: 'Suspicious Traffic', msg: `Unusual ${packet.protocol} traffic from ${packet.src}` },
      { title: 'Port Scan Detected', msg: `Port ${packet.port} scanning from ${packet.src}` },
    ];
    const t = threats[Math.floor(Math.random() * threats.length)];
    if (typeof showAlert === 'function') showAlert(t.title, t.msg, 'warning');
  }

  if (packet.status === 'blocked' && Math.random() > 0.85) {
    if (typeof showAlert === 'function') {
      showAlert('Threat Blocked', `Malicious ${packet.protocol} packet from ${packet.src} blocked`, 'success');
    }
  }
}

function initTrafficMonitor() {
  // Clear existing
  const feed = document.getElementById('trafficFeed');
  if (feed) feed.innerHTML = '';

  // Generate initial batch
  for (let i = 0; i < 15; i++) {
    addTrafficRow(generateTrafficPacket());
  }

  // Continuous generation
  setInterval(() => {
    addTrafficRow(generateTrafficPacket());
  }, 800);
}
