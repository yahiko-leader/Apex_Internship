

console.log("%c👋 Hi! I'm Nikhil Prajapati", "color:#6366f1; font-size:18px; font-weight:bold;");
console.log("%cWelcome to my Internship Task project ✨", "color:#ec4899; font-size:14px;");


const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');

menuToggle.addEventListener('click', () => navLinks.classList.toggle('active'));

document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => navLinks.classList.remove('active'));
});

document.addEventListener('click', (e) => {
  if (!navLinks.contains(e.target) && !menuToggle.contains(e.target)) {
    navLinks.classList.remove('active');
  }
});


const form = document.getElementById('contactForm');
const successMsg = document.getElementById('successMsg');

const fields = {
  name: { el: document.getElementById('name'), err: document.getElementById('nameError') },
  email: { el: document.getElementById('email'), err: document.getElementById('emailError') },
  phone: { el: document.getElementById('phone'), err: document.getElementById('phoneError') },
  subject: { el: document.getElementById('subject'), err: document.getElementById('subjectError') },
  message: { el: document.getElementById('message'), err: document.getElementById('messageError') },
};

function setError(field, msg) {
  field.err.textContent = msg;
  field.el.classList.add('invalid');
}
function clearError(field) {
  field.err.textContent = '';
  field.el.classList.remove('invalid');
}

function validateForm() {
  let isValid = true;
  Object.values(fields).forEach(clearError);
  successMsg.textContent = '';

  if (fields.name.el.value.trim().length < 2) {
    setError(fields.name, '⚠ Please enter your full name (min 2 characters).');
    isValid = false;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(fields.email.el.value.trim())) {
    setError(fields.email, '⚠ Please enter a valid email address.');
    isValid = false;
  }

  const phoneVal = fields.phone.el.value.trim();
  if (phoneVal && !/^[\d\s+\-()]{7,}$/.test(phoneVal)) {
    setError(fields.phone, '⚠ Please enter a valid phone number.');
    isValid = false;
  }

  if (!fields.subject.el.value) {
    setError(fields.subject, '⚠ Please select a subject.');
    isValid = false;
  }

  if (fields.message.el.value.trim().length < 10) {
    setError(fields.message, '⚠ Message must be at least 10 characters long.');
    isValid = false;
  }

  return isValid;
}

form.addEventListener('submit', e => {
  e.preventDefault();
  if (validateForm()) {
    successMsg.textContent = '✅ Thank you! Your message has been sent successfully.';
    form.reset();
    setTimeout(() => (successMsg.textContent = ''), 5000);
  }
});

Object.values(fields).forEach(f => {
  f.el.addEventListener('input', () => clearError(f));
});


const todoInput = document.getElementById('todoInput');
const addTodoBtn = document.getElementById('addTodo');
const todoList = document.getElementById('todoList');
const emptyMsg = document.getElementById('emptyMsg');
const todoCount = document.getElementById('todoCount');
const clearAllBtn = document.getElementById('clearAll');

const STORAGE_KEY = 'nikhil_todos';
let todos = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];

function saveTodos() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(todos));
}

function updateStats() {
  const total = todos.length;
  const done = todos.filter(t => t.completed).length;
  todoCount.textContent = total === 0
    ? '0 tasks'
    : `${done} of ${total} completed`;
  emptyMsg.style.display = total === 0 ? 'block' : 'none';
  clearAllBtn.style.display = total === 0 ? 'none' : 'inline-block';
}

function renderTodos() {
  todoList.innerHTML = '';
  todos.forEach((todo, index) => {
    const li = document.createElement('li');
    if (todo.completed) li.classList.add('completed');
    li.innerHTML = `
      <span class="task-text">${escapeHtml(todo.text)}</span>
      <button class="delete-btn" aria-label="Delete task">✕ Delete</button>
    `;

    li.querySelector('.task-text').addEventListener('click', () => {
      todos[index].completed = !todos[index].completed;
      saveTodos();
      renderTodos();
    });

    li.querySelector('.delete-btn').addEventListener('click', () => {
      li.style.opacity = '0';
      li.style.transform = 'translateX(30px)';
      li.style.transition = 'all 0.3s';
      setTimeout(() => {
        todos.splice(index, 1);
        saveTodos();
        renderTodos();
      }, 300);
    });

    todoList.appendChild(li);
  });
  updateStats();
}

function addTodo() {
  const text = todoInput.value.trim();
  if (!text) {
    todoInput.focus();
    return;
  }
  todos.push({ text, completed: false });
  saveTodos();
  renderTodos();
  todoInput.value = '';
  todoInput.focus();
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

addTodoBtn.addEventListener('click', addTodo);
todoInput.addEventListener('keypress', e => {
  if (e.key === 'Enter') addTodo();
});

clearAllBtn.addEventListener('click', () => {
  if (todos.length === 0) return;
  if (confirm('Clear all tasks? This cannot be undone.')) {
    todos = [];
    saveTodos();
    renderTodos();
  }
});

renderTodos();


const imgInput = document.getElementById('imgInput');
const addImgBtn = document.getElementById('addImg');
const gallery = document.getElementById('gallery');

const sampleImages = [
  'https://images.unsplash.com/photo-1518770660439-4636190af475?w=500&q=80',
  'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=500&q=80',
  'https://images.unsplash.com/photo-1551434678-e076c223a692?w=500&q=80',
  'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=500&q=80',
  'https://images.unsplash.com/photo-1607743386760-88ac62b89b8a?w=500&q=80',
  'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=500&q=80'
];

function addImage(url) {
  const wrap = document.createElement('div');
  wrap.className = 'img-wrap';

  const img = document.createElement('img');
  img.src = url;
  img.alt = 'Gallery image';

  const overlay = document.createElement('div');
  overlay.className = 'img-overlay';
  overlay.textContent = '🗑 Click to remove';

  wrap.appendChild(img);
  wrap.appendChild(overlay);

  wrap.addEventListener('click', () => {
    if (confirm('Remove this image from the gallery?')) {
      wrap.style.opacity = '0';
      wrap.style.transform = 'scale(0.85)';
      wrap.style.transition = 'all 0.3s';
      setTimeout(() => wrap.remove(), 300);
    }
  });

  img.addEventListener('error', () => {
    alert('⚠ Could not load that image. Please check the URL.');
    wrap.remove();
  });

  gallery.appendChild(wrap);
}

sampleImages.forEach(addImage);

addImgBtn.addEventListener('click', () => {
  const url = imgInput.value.trim();
  if (!url) return;
  addImage(url);
  imgInput.value = '';
});

imgInput.addEventListener('keypress', e => {
  if (e.key === 'Enter') addImgBtn.click();
});
