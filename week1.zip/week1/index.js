
 const button = document.getElementById('alertBtn');

button.addEventListener('click', function () {
    alert('Hello! I am a beginner frontend developer.');
});	

