        const API_KEY = '1872aa60'; 
        
        const searchInput = document.getElementById('search-input');
        const searchBtn = document.getElementById('search-btn');
        const movieGrid = document.getElementById('movie-grid');
        const statusMsg = document.getElementById('status');

       async function fetchMovies(searchTerm) {
            try {
                // Clear UI and show loading text
                movieGrid.innerHTML = '';
                statusMsg.style.display = 'block';
                statusMsg.innerText = 'Searching the database...';

                // Fetch data from OMDb API
                const response = await fetch(`https://www.omdbapi.com/?s=${encodeURIComponent(searchTerm)}&apikey=${API_KEY}`);
                const data = await response.json();

                if (data.Response === "True") {
                    statusMsg.style.display = 'none'; 
                    renderMovies(data.Search);
                } else {
                    statusMsg.innerText = `No results found for "${searchTerm}". (${data.Error})`;
                }
            } catch (error) {
                statusMsg.innerText = 'Failed to fetch data. Please check your internet connection.';
                console.error("API Error:", error);
            }
        }

        function renderMovies(movies) {
            movies.forEach(movie => {
                // Use a placeholder image if the API doesn't have a poster for the movie
                const posterSrc = movie.Poster !== "N/A" ? movie.Poster : 'https://via.placeholder.com/300x450/2a2a2a/ffffff?text=No+Poster';

                const card = document.createElement('div');
                card.className = 'movie-card';
                card.innerHTML = `
                    <img src="${posterSrc}" alt="${movie.Title}" class="movie-poster">
                    <div class="movie-info">
                        <div class="movie-title">${movie.Title}</div>
                        <div class="movie-year">${movie.Year} • ${movie.Type}</div>
                    </div>
                `;
                movieGrid.appendChild(card);
            });
        }

        // Trigger search on button click
        searchBtn.addEventListener('click', () => {
            const query = searchInput.value.trim();
            if (query) fetchMovies(query);
        });

        // Trigger search on "Enter" key press
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const query = searchInput.value.trim();
                if (query) fetchMovies(query);
            }
        });